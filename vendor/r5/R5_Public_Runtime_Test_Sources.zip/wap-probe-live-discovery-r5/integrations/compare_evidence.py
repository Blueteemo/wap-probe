#!/usr/bin/env python3
"""Correlate a wapcurl import with a separate direct HTTP/WML evidence record.

Never promotes a gateway outcome into original HTTP origin verification.
Only compares matching public URL + exact body SHA256 and reports provenance.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def correlate(labs: dict, http_report: dict) -> dict:
    if not isinstance(labs, dict) or not isinstance(http_report, dict):
        raise ValueError('Both inputs must contain JSON objects')
    records = http_report.get('records', [http_report.get('record')] if 'record' in http_report else [])
    if not isinstance(records, list):
        raise ValueError('Invalid HTTP report shape')
    if labs.get('transport') != 'http':
        return {'same_response_bytes': False, 'same_url': False, 'status': 'not_comparable_gateway',
                'origin_grade_promoted': False, 'notes':'WSP/bridged gateway is a separate transport; HTTP origin comparison is not applicable.'}
    same_url = [r for r in records if isinstance(r,dict) and r.get('final_url') == labs.get('final_url')]
    matches = [r for r in same_url if r.get('sha256') == labs.get('sha256') and r.get('sha256')]
    if len(matches) == 1:
        r = matches[0]
        answer = {
            'status':'same_response_bytes', 'same_url':True, 'same_response_bytes':True,
            'body_sha256':labs['sha256'], 'direct_http_grade_as_reported':r.get('grade'),
            'direct_http_content_type_as_reported':r.get('content_type'),
            'direct_capture_provenance':r.get('evidence_origin','unverified_report'),
            'raw_content_grade_from_wapcurl':labs.get('raw_content_grade'),
            'origin_grade_promoted':False,
            'notes':'Two externally supplied reports describe the same URL and identical bytes; collector authenticity/headers are NOT independently verified.'}
        return answer
    if len(matches) > 1:
        return {'status':'ambiguous_multiple_direct_records','same_url':True,'same_response_bytes':True,
                'origin_grade_promoted':False,'notes':'Multiple matching HTTP records require manual selection.'}
    return {'status':'different_bytes_or_no_corresponding_record', 'same_url':bool(same_url),
            'same_response_bytes':False,'origin_grade_promoted':False,
            'notes':'Do not infer same response from similar text or MIME. Content might change dynamically.'}


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--wapcurl-report',type=Path,required=True)
    ap.add_argument('--http-report',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args(argv)
    labs=json.loads(a.wapcurl_report.read_text(encoding='utf-8'))
    http=json.loads(a.http_report.read_text(encoding='utf-8'))
    outcome=correlate(labs,http)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(outcome,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(outcome['status'],'; origin grade promoted:',outcome['origin_grade_promoted'])
    return 0
if __name__=='__main__':raise SystemExit(main())
