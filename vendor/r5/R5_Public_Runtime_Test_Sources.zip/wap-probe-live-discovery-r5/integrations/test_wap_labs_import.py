"""Synthetic schema fixtures ONLY; NOT generated from an actual wapcurl run."""
import base64
import hashlib
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from wap_labs_import import import_wapcurl, ImportFailure

WML=b'<?xml version="1.0"?><wml><card id="home" title="Demo"><p><a href="#two">Next</a></p></card><card id="two"><p>Done</p></card></wml>'

def payload(raw=WML, *, transport='http', url='http://demo.example/page.wml', gateway=None,
            ct='text/vnd.wap.wml', ok=True, status=200, wml=None):
    return {'requestedUrl':url,'finalUrl':url,'gateway':gateway,'ok':ok,'status':status,
            'outcome':'success' if ok else 'GATEWAY_TIMEOUT','contentType':ct,'byteCount':len(raw),
            'elapsedMs':12.5,'transport':transport,'decode':'text-wml',
            'wml':wml if wml is not None else (raw.decode('utf-8') if ok else None),
            'rawBytesBase64':base64.b64encode(raw).decode('ascii'), 'error':None}

class LabsImportTests(unittest.TestCase):
    def test_direct_http_never_awards_origin_a_on_normalized_mime(self):
        rec, data=import_wapcurl(payload())
        self.assertEqual(data,WML)
        self.assertEqual(rec['raw_content_grade'],'A-wml-verified')
        self.assertEqual(rec['origin_wml_grade'],'U-needs-original-http-headers')
        self.assertFalse(rec['content_type_wire_verified'])
        self.assertEqual(rec['decode_parity'],'matching_cards_and_links')
    def test_native_wsp_gateway_not_origin_grade(self):
        rec,_=import_wapcurl(payload(transport='wsp-connectionless/wdp-udp',url='wap://demo.example/page.wml',gateway='wap://159.89.254.0:9200'))
        self.assertEqual(rec['origin_wml_grade'],'not_applicable_gateway_transport')
        self.assertTrue(rec['gateway_used'])
    def test_http_bridge_not_origin_grade(self):
        rec,_=import_wapcurl(payload(transport='gateway-bridged/http',url='wap://demo.example/page.wml',gateway='http://bridge.example'))
        self.assertEqual(rec['origin_wml_grade'],'not_applicable_gateway_transport')
    def test_decode_mismatch_fails_closed(self):
        bad=WML.replace(b'Done',b'Secret')
        rec,_=import_wapcurl(payload(wml=bad.decode()))
        self.assertEqual(rec['decode_parity'],'different_or_unreadable')
        self.assertEqual(rec['raw_content_grade'],'U-decoder-disagreement')
    def test_empty_raw_success_rejected(self):
        p=payload(raw=b'')
        with self.assertRaises(ImportFailure): import_wapcurl(p)
    def test_mismatched_byte_count_rejected(self):
        p=payload();p['byteCount']+=1
        with self.assertRaises(ImportFailure): import_wapcurl(p)
    def test_bad_base64_rejected(self):
        p=payload();p['rawBytesBase64']='%%%%'
        with self.assertRaises(ImportFailure): import_wapcurl(p)
    def test_hash_mismatch_rejected(self):
        with self.assertRaises(ImportFailure): import_wapcurl(payload(),expected_sha256='0'*64)
    def test_correct_hash(self):
        rec,_=import_wapcurl(payload(),expected_sha256=hashlib.sha256(WML).hexdigest())
        self.assertEqual(rec['raw_byte_count'],len(WML))
    def test_transport_scheme_mismatch_rejected(self):
        with self.assertRaises(ImportFailure): import_wapcurl(payload(transport='wsp-connectionless/wdp-udp'))
    def test_gateway_required(self):
        with self.assertRaises(ImportFailure): import_wapcurl(payload(transport='wsp-connectionless/wdp-udp',url='wap://demo.example/'))
    def test_direct_gateway_forbidden(self):
        with self.assertRaises(ImportFailure): import_wapcurl(payload(gateway='wap://gateway.example:9200'))
    def test_credentials_rejected(self):
        with self.assertRaises(ImportFailure): import_wapcurl(payload(url='http://user:pass@demo.example'))
    def test_sensitive_query_rejected(self):
        with self.assertRaises(ImportFailure): import_wapcurl(payload(url='http://demo.example/?token=secret'))
    def test_failed_wsp_not_origin(self):
        p=payload(transport='wsp-connectionless/wdp-udp',url='wap://demo.example/',gateway='wap://gateway.example:9200',ok=False,status=0,raw=b'')
        rec,_=import_wapcurl(p)
        self.assertEqual(rec['raw_content_grade'],'U-transport-or-status')
        self.assertEqual(rec['origin_wml_grade'],'not_applicable_gateway_transport')
    def test_corrupt_wml_not_a(self):
        p=payload(raw=b'<wml><card>',wml='<wml><card>')
        rec,_=import_wapcurl(p)
        self.assertFalse(rec['raw_content_grade'].startswith('A-'))
    def test_truncation_rejected_by_count_cap(self):
        p=payload();p['byteCount']=524289
        with self.assertRaises(ImportFailure):import_wapcurl(p)
    def test_nested_invalid_output_rejected(self):
        with self.assertRaises(ImportFailure):import_wapcurl(['not','dict'])
    def test_localhost_rejected_as_shareable(self):
        with self.assertRaises(ImportFailure):import_wapcurl(payload(url='http://localhost:8000/'))

if __name__=='__main__': unittest.main()

# Extra coverage for the real *bytes* in the prior DeepSeek capture; the
# reconstructed wapcurl-shaped JSON remains SYNTHETIC, not real CLI evidence.
class HistoricBodyReplayTests(unittest.TestCase):
    def test_prior_real_body_through_synthetic_wapcurl_json_envelope(self):
        import json, zipfile
        archive=Path(__file__).resolve().parents[1]/'probe/research/deepseek_review_original.zip'
        if not archive.exists():
            self.skipTest('External HTTP research captures preserved in private backup')
        with zipfile.ZipFile(archive) as z:
            walk=json.loads(z.read('deepseek_review/evidence/live_walk_bs0dd/walk.json'))
            entry=walk['fetches'][0]
            filename='deepseek_review/evidence/live_walk_bs0dd/evidence/'+entry['sha256']+'.bin'
            raw=z.read(filename)
        self.assertEqual(hashlib.sha256(raw).hexdigest(),entry['sha256'])
        result,_=import_wapcurl(payload(raw, url=entry['url'], ct=entry['content_type'], wml=raw.decode('utf-8')))
        self.assertEqual(result['raw_content_grade'],'A-wml-verified')
        self.assertEqual(result['origin_wml_grade'],'U-needs-original-http-headers')
        self.assertEqual(result['analysis']['cards'][0]['id'],'card1')

    def test_wmlc_synthetic_envelope(self):
        import importlib.util
        fixture=Path(__file__).resolve().parents[1]/'probe/fixtures/binary_portal.wmlc'
        raw=fixture.read_bytes()
        pp=Path(__file__).resolve().parents[1]/'probe'
        sys.path.insert(0,str(pp))
        import wap_wbxml
        normalized,_ = wap_wbxml.decode_wmlc(raw)
        rec,_=import_wapcurl(payload(raw,ct='application/vnd.wap.wmlc',wml=normalized.decode('utf-8')))
        self.assertEqual(rec['raw_content_grade'],'A-wmlc-verified')
        self.assertEqual(rec['decode_parity'],'matching_cards_and_links')
        self.assertEqual(rec['origin_wml_grade'],'U-needs-original-http-headers')

class URLGuardTests(unittest.TestCase):
    def test_private_ipv4_resource_rejected(self):
        with self.assertRaises(ImportFailure): import_wapcurl(payload(url='http://127.0.0.1/wap'))
    def test_private_ipv4_gateway_rejected(self):
        with self.assertRaises(ImportFailure): import_wapcurl(payload(url='wap://test.example/',gateway='wap://192.168.1.1:9200',transport='wsp-connectionless/wdp-udp'))
    def test_control_character_mime_rejected(self):
        with self.assertRaises(ImportFailure):import_wapcurl(payload(ct='text/vnd.wap.wml\nmalicious'))
    def test_sid_query_rejected(self):
        with self.assertRaises(ImportFailure):import_wapcurl(payload(url='http://test.example/?sid=123'))
