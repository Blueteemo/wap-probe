"""All tests are isolated; no real external WAP requests or Rust binary required."""
from __future__ import annotations
import base64
import json
from pathlib import Path
import stat
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_wapcurl import RunFailure, run_once, validate_request

WML=b'<?xml version="1.0"?><wml><card id="start"><p>Hello</p></card></wml>'
URL='wap://example.org/index.wml'
GATEWAY='159.89.254.0:9200'


def mock_response(*, mode='native', url=URL, gateway='wap://'+GATEWAY,
                  ok=True, status=200, data=WML, mime='text/vnd.wap.wml'):
    return {'requestedUrl':url,'finalUrl':url,'gateway':gateway,
            'transport':('wsp-connectionless/wdp-udp' if mode=='native' else 'http'),
            'ok':ok,'status':status,'outcome':'success' if ok else 'TRANSPORT_UNAVAILABLE',
            'contentType':mime,'byteCount':len(data),'elapsedMs':3.0,'decode':'text-wml',
            'wml':data.decode() if ok and mime == 'text/vnd.wap.wml' else None,
            'rawBytesBase64':base64.b64encode(data).decode(), 'error': None}


class RunnerTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.executable=self.root/'wapcurl'
    def tearDown(self):
        self.tmp.cleanup()
    def make_stub(self,obj,exit_code=0):
        fixture=self.root/'fake.json';fixture.write_text(json.dumps(obj),encoding='utf-8')
        self.executable.write_text('#!/usr/bin/env python3\n'
            'from pathlib import Path\nimport sys\n'
            f'sys.stdout.write(Path({str(fixture)!r}).read_text())\n'
            f'sys.exit({exit_code})\n',encoding='utf-8')
        self.executable.chmod(self.executable.stat().st_mode|stat.S_IXUSR)
    def test_native_success_and_hashes(self):
        self.make_stub(mock_response())
        dest=self.root/'capture'
        summary=run_once(self.executable, URL, mode='native',gateway=GATEWAY,out=dest)
        self.assertEqual((dest/'raw_response.bin').read_bytes(),WML)
        self.assertTrue((dest/'wapcurl_stdout.json').exists())
        self.assertEqual(summary['origin_wml_grade'],'not_applicable_gateway_transport')
        self.assertTrue(summary['gateway_result_cannot_verify_origin_http'])
        self.assertFalse(summary['stderr_stored'])
        self.assertEqual(len(summary['response_sha256']),64)
    def test_direct_http_never_origin_a(self):
        url='http://demo.example/index.wml'
        self.make_stub(mock_response(mode='direct',url=url,gateway=None))
        summary=run_once(self.executable,url,mode='direct',gateway=None,out=self.root/'out')
        self.assertEqual(summary['origin_wml_grade'],'U-needs-original-http-headers')
    def test_refuse_overwrite(self):
        self.make_stub(mock_response())
        existing=self.root/'capture';existing.mkdir()
        with self.assertRaisesRegex(RunFailure,'already exists'):
            run_once(self.executable,URL,mode='native',gateway=GATEWAY,out=existing)
    def test_json_url_mismatch_rejected_without_artefacts(self):
        self.make_stub(mock_response(url='wap://other.example/index.wml'))
        dest=self.root/'capture'
        with self.assertRaisesRegex(RunFailure,'Requested URL'):
            run_once(self.executable,URL,mode='native',gateway=GATEWAY,out=dest)
        self.assertFalse(dest.exists())
    def test_json_gateway_mismatch_rejected(self):
        self.make_stub(mock_response(gateway='wap://example.net:9200'))
        with self.assertRaisesRegex(RunFailure,'gateway different'):
            run_once(self.executable,URL,mode='native',gateway=GATEWAY,out=self.root/'capture')
    def test_exit_status_inconsistent_rejected(self):
        self.make_stub(mock_response(),exit_code=6)
        with self.assertRaisesRegex(RunFailure,'failure but JSON reports success'):
            run_once(self.executable,URL,mode='native',gateway=GATEWAY,out=self.root/'capture')
    def test_invalid_output_rejected(self):
        self.make_stub({'junk':'not a response'})
        with self.assertRaisesRegex(RunFailure,'Invalid or unverifiable'):
            run_once(self.executable,URL,mode='native',gateway=GATEWAY,out=self.root/'capture')
    def test_native_binary_wmlc_end_to_end_with_fake_executable(self):
        probe_dir=Path(__file__).resolve().parents[1]/'probe'
        sys.path.insert(0,str(probe_dir))
        import wap_wbxml
        data=(probe_dir/'fixtures/binary_portal.wmlc').read_bytes()
        normalized,_=wap_wbxml.decode_wmlc(data)
        message=mock_response(data=data,mime='application/vnd.wap.wmlc')
        message['wml']=normalized.decode('utf-8')
        message['decode']='wbxml-to-wml'
        self.make_stub(message)
        dest=self.root/'binary-capture'
        run_once(self.executable,URL,mode='native',gateway=GATEWAY,out=dest)
        report=json.loads((dest/'report.json').read_text())
        self.assertEqual(report['analysis']['format'],'wmlc')
        self.assertEqual(report['decode_parity'],'matching_cards_and_links')
        self.assertEqual(report['origin_wml_grade'],'not_applicable_gateway_transport')
        self.assertEqual((dest/'raw_response.bin').read_bytes(),data)
    def test_failed_native_request_retains_bounded_failure_evidence(self):
        message=mock_response(ok=False,status=0,data=b'')
        message['wml']=None
        message['decode']='not-decoded'
        self.make_stub(message,exit_code=5)
        dest=self.root/'failure'
        summary=run_once(self.executable,URL,mode='native',gateway=GATEWAY,out=dest)
        report=json.loads((dest/'report.json').read_text())
        self.assertEqual(summary['wapcurl_exit_code'],5)
        self.assertEqual(report['raw_content_grade'],'U-transport-or-status')
        self.assertEqual((dest/'raw_response.bin').read_bytes(),b'')
    def test_private_destination_rejected(self):
        with self.assertRaises(Exception): validate_request('native','wap://127.0.0.1/',GATEWAY)
    def test_private_gateway_rejected(self):
        with self.assertRaises(Exception): validate_request('native',URL,'192.168.1.1:9200')
    def test_direct_mode_gateway_rejected(self):
        with self.assertRaises(RunFailure): validate_request('direct','http://example.org/','gw.example.org')
    def test_native_without_gateway_rejected(self):
        with self.assertRaises(RunFailure): validate_request('native',URL,None)
    def test_sensitive_resource_rejected(self):
        with self.assertRaises(Exception): validate_request('native',URL+'?token=secret',GATEWAY)
    def test_native_rejects_gateway_path(self):
        with self.assertRaises(RunFailure): validate_request('native',URL,'wap://gw.example.org/bridge')
    def test_wrong_url_scheme_rejected(self):
        with self.assertRaises(RunFailure): validate_request('native','https://example.org/',GATEWAY)

if __name__=='__main__': unittest.main()
