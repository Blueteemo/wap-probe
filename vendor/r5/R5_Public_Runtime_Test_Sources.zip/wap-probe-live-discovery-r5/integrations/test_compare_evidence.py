import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from compare_evidence import correlate

class CorrelationTests(unittest.TestCase):
    base={'transport':'http','final_url':'http://demo.example/','sha256':'ff'*32,'raw_content_grade':'A-wml-verified'}
    direct={'records':[{'final_url':'http://demo.example/','sha256':'ff'*32,
                        'grade':'A-wml-verified','content_type':'text/vnd.wap.wml','evidence_origin':'user_supplied_http_capture'}]}
    def test_matching_report_does_not_promote_origin_grade(self):
        res=correlate(self.base,self.direct)
        self.assertTrue(res['same_response_bytes'])
        self.assertFalse(res['origin_grade_promoted'])
        self.assertEqual(res['direct_http_grade_as_reported'],'A-wml-verified')
    def test_nonmatching_content(self):
        res=correlate({**self.base,'sha256':'ee'*32},self.direct)
        self.assertFalse(res['same_response_bytes'])
    def test_different_url(self):
        res=correlate({**self.base,'final_url':'http://other.example/'},self.direct)
        self.assertFalse(res['same_url'])
    def test_gateway_never_compares_as_origin(self):
        res=correlate({**self.base,'transport':'wsp-connectionless/wdp-udp'},self.direct)
        self.assertEqual(res['status'],'not_comparable_gateway')
        self.assertFalse(res['origin_grade_promoted'])
    def test_duplicate_candidates_mark_ambiguous(self):
        res=correlate(self.base,{'records':self.direct['records']*2})
        self.assertEqual(res['status'],'ambiguous_multiple_direct_records')
    def test_single_record_shape(self):
        res=correlate(self.base,{'record':self.direct['records'][0]})
        self.assertTrue(res['same_response_bytes'])
    def test_invalid_shape(self):
        with self.assertRaises(ValueError):correlate(self.base,{'records':'invalid'})

if __name__=='__main__':unittest.main()
