#!/usr/bin/env python3
"""Read-only, offline importer for WAP Labs `wapcurl --json` output.

Crucial distinction: wapcurl's contentType may be *normalized*. Therefore
this importer NEVER awards a direct-origin A grade without separate wire
headers. Even WSP/WDP success via a gateway proves only gateway behavior.

No networking, subprocess execution or public host probing is performed.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import ipaddress
import json
import sys
from pathlib import Path
from urllib.parse import urlsplit, parse_qsl

PROBE = Path(__file__).resolve().parents[1] / 'probe'
sys.path.insert(0, str(PROBE))
import wap_probe as probe

MAX_INPUT_JSON = 2 * 1024 * 1024
MAX_BODY = 524_288
TRANSPORT_SCHEMES = {
    'http': {'http', 'https'},
    'wsp-connectionless/wdp-udp': {'wap', 'waps'},
    'gateway-bridged/http': {'wap', 'waps'},
}
SENSITIVE = {'token', 'password', 'passwd', 'auth', 'authorization', 'key', 'apikey', 'api_key', 'secret', 'session', 'sessionid', 'sid', 'access_token', 'refresh_token', 'jwt', 'code'}

class ImportFailure(ValueError):
    pass


def safe_url(value: object) -> str:
    if not isinstance(value, str) or len(value) > 1024 or any(ord(c) < 32 for c in value):
        raise ImportFailure('Invalid URL')
    try:
        u = urlsplit(value)
        if (u.scheme not in ('http', 'https', 'wap', 'waps') or not u.hostname or
                u.username is not None or u.password is not None or u.fragment):
            raise ImportFailure('URL is not a safe public research URL')
        host = u.hostname.lower()
        if host == 'localhost' or host.endswith(('.internal', '.local', '.localhost')):
            raise ImportFailure('Private hostname forbidden in shareable results')
        try:
            literal = ipaddress.ip_address(host.strip('[]'))
        except ValueError:
            pass
        else:
            if not literal.is_global:
                raise ImportFailure('Private/reserved IP forbidden in shareable results')
        if any(k.lower() in SENSITIVE for k, _ in parse_qsl(u.query, keep_blank_values=True)):
            raise ImportFailure('URL contains sensitive query parameters')
    except ValueError as exc:
        raise ImportFailure('Invalid URL structure') from exc
    return value


def card_snapshot(info: dict) -> list[dict]:
    result = []
    for card in info.get('cards', []):
        result.append({'id': card.get('id'), 'title': card.get('title'),
                       'text': ' '.join((card.get('text') or '').split()),
                       'links': [(link.get('href'), link.get('method', 'get')) for link in card.get('links', [])]})
    return result


def import_wapcurl(obj: object, *, expected_sha256: str | None = None) -> tuple[dict, bytes]:
    if not isinstance(obj, dict):
        raise ImportFailure('JSON root must be an object')
    requested = safe_url(obj.get('requestedUrl'))
    final = safe_url(obj.get('finalUrl'))
    scheme = urlsplit(requested).scheme
    transport = obj.get('transport')
    if transport not in TRANSPORT_SCHEMES or scheme not in TRANSPORT_SCHEMES[transport]:
        raise ImportFailure('URL scheme and transport disagree, or transport not recognized')
    if urlsplit(final).scheme != scheme:
        raise ImportFailure('Unexpected final URL scheme change; manual review required')
    gateway = obj.get('gateway')
    if transport != 'http' and (not isinstance(gateway, str) or not gateway):
        raise ImportFailure('Gateway-based capture missing gateway address')
    if transport == 'http' and gateway is not None:
        raise ImportFailure('Direct HTTP capture cannot include a gateway')
    if gateway is not None:
        # No credentials, secrets or control characters may be copied into reports.
        safe_url(gateway if '://' in gateway else 'wap://' + gateway)
    success = obj.get('ok')
    status = obj.get('status')
    if not isinstance(success, bool) or type(status) is not int or not 0 <= status <= 599:
        raise ImportFailure('Invalid outcome or status')
    content_type = obj.get('contentType')
    if (not isinstance(content_type, str) or len(content_type) > 256 or
            any(ord(c) < 32 for c in content_type)):
        raise ImportFailure('Missing or invalid contentType')
    count = obj.get('byteCount')
    if type(count) is not int or not 0 <= count <= MAX_BODY:
        raise ImportFailure('Invalid byteCount')
    b64 = obj.get('rawBytesBase64')
    if b64 is None:
        if success:
            raise ImportFailure('Successful request requires raw bytes for independent verification')
        raw = b''
    elif isinstance(b64, str) and len(b64) <= 4 * ((MAX_BODY + 2) // 3):
        try:
            raw = base64.b64decode(b64, validate=True)
        except (ValueError, binascii.Error) as exc:
            raise ImportFailure('Malformed rawBytesBase64') from exc
    else:
        raise ImportFailure('Invalid or oversized base64 payload')
    if len(raw) != count:
        raise ImportFailure('Raw bytes length differs from CLI byteCount')
    if success and not raw:
        raise ImportFailure('Successful response lacks raw bytes; cannot independently inspect WML')
    digest = hashlib.sha256(raw).hexdigest()
    if expected_sha256 is not None and digest != expected_sha256.lower():
        raise ImportFailure('Original-byte SHA256 mismatch')
    normalized = obj.get('wml')
    if normalized is not None and (not isinstance(normalized, str) or len(normalized) > MAX_BODY * 2):
        raise ImportFailure('Invalid normalized WML')
    analysis = probe.inspect_markup(raw, content_type) if raw else {
        'format': 'unavailable', 'mime': probe.mime_type(content_type)[0],
        'cards': [], 'links': [], 'notes': ['No raw bytes in upstream response'], 'valid_xml': None}
    provided_analysis = probe.inspect_markup(normalized.encode('utf-8'), 'text/vnd.wap.wml; charset=utf-8') if normalized else None
    if provided_analysis is None:
        parity = 'not_provided'
    elif provided_analysis.get('valid_xml') is not True or provided_analysis.get('format') != 'wml':
        parity = 'upstream_wml_invalid'
    elif analysis.get('valid_xml') is True and card_snapshot(analysis) == card_snapshot(provided_analysis):
        parity = 'matching_cards_and_links'
    else:
        parity = 'different_or_unreadable'

    candidate = {
        'status': status if success else None,
        'error': None if success else 'upstream_transport_failed',
        'analysis': analysis, 'redirects': [],
    }
    content_grade, content_reason = probe.grade(candidate)
    if not success or not 200 <= status < 300:
        content_grade = 'U-transport-or-status'
    if parity in ('different_or_unreadable', 'upstream_wml_invalid') and success:
        content_grade = 'U-decoder-disagreement'
    origin_grade = 'U-needs-original-http-headers' if transport == 'http' else 'not_applicable_gateway_transport'
    if not success:
        origin_grade = 'U-transport-failed' if transport == 'http' else 'not_applicable_gateway_transport'
    record = {
        'source': 'externally_supplied_wapcurl_json',
        'source_authenticated': False,
        'network_performed_by_importer': False,
        'requested_url': requested,
        'final_url': final,
        'redirected': requested != final,
        'transport': transport,
        'gateway': gateway,
        'gateway_used': transport != 'http',
        'upstream_ok': success,
        'status': status,
        'upstream_outcome': str(obj.get('outcome', 'unknown'))[:80],
        'content_type_reported_by_wapcurl': content_type,
        'content_type_wire_verified': False,
        'raw_byte_count': len(raw),
        'sha256': digest,
        'analysis': analysis,
        'raw_content_grade': content_grade,
        'raw_content_reason': content_reason,
        'decode_parity': parity,
        'origin_wml_grade': origin_grade,
        'original_http_server_wml_verified': False,
        'limitations': [
            'JSON is externally supplied, not authenticated by this importer.',
            'wapcurl reports a normalized content type, not guaranteed original HTTP Content-Type.',
            'WSP/WDP gateway response is not evidence that the HTTP origin itself serves WML.',
            'Physical old-phone compatibility is not tested.',
        ],
    }
    return record, raw


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description='Offline import of WAP Labs wapcurl --json evidence (NO network)')
    ap.add_argument('--input', type=Path, required=True, help='Saved stdout from wapcurl --json')
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--expect-sha256', help='Optional expected SHA256 of original response bytes')
    args = ap.parse_args(argv)
    if args.input.stat().st_size > MAX_INPUT_JSON:
        ap.error('JSON input exceeds 2 MiB')
    try:
        obj = json.loads(args.input.read_text(encoding='utf-8'))
        rec, raw = import_wapcurl(obj, expected_sha256=args.expect_sha256)
    except (ImportFailure, ValueError, UnicodeError) as exc:
        ap.error(str(exc))
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out/'raw_response.bin').write_bytes(raw)
    (args.out/'report.json').write_text(json.dumps(rec, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    summary = [
        '# WAP Labs → WAP Probe evidence import', '',
        '**This importer performs no network requests and verifies no real-world collection provenance.**', '',
        f"- Requested URL: `{rec['requested_url']}`",
        f"- Transport: `{rec['transport']}`",
        f"- Gateway used: `{rec['gateway_used']}`",
        f"- Tool reported status: `{rec['status']}`",
        f"- Reported/normalized MIME: `{rec['content_type_reported_by_wapcurl']}`",
        f"- Bytes: {rec['raw_byte_count']}; SHA256: `{rec['sha256']}`",
        f"- Raw format evaluation: **{rec['raw_content_grade']}**",
        f"- Decoders agree: `{rec['decode_parity']}`",
        f"- Original-site WML conclusion: **{rec['origin_wml_grade']}**", '',
        '## Evidence boundaries', '',
    ] + [f'- {x}' for x in rec['limitations']]
    (args.out/'report.md').write_text('\n'.join(summary)+'\n', encoding='utf-8')
    print(f"transport={rec['transport']} format={rec['analysis']['format']} "
          f"raw={rec['raw_content_grade']} origin={rec['origin_wml_grade']}")
    print('Report:', args.out/'report.md')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
