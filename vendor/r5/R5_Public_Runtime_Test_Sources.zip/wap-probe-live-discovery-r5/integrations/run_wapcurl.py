#!/usr/bin/env python3
"""Execute an explicitly selected wapcurl binary, then import its raw JSON evidence.

This is a *bounded*, opt-in collection helper, not an autonomous crawler:
- a single explicit URL; public HTTP(S) or WAP resource only;
- never asks wapcurl to allow-private; never retries;
- native WSP requires an explicit public gateway;
- no credentials, cookies, user-supplied headers, or automatic redirects to another site
  are requested by this runner (wapcurl may follow its own bounded redirects);
- captures stdout, hashes it, and preserves unmodified evidence in a new folder;
- never treats a WSP gateway response as proof of origin HTTP WML support.

The program requires a locally installed upstream wapcurl. It does not vendor or
compile WAP Labs and never claims that a captured response is authenticated.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlsplit

from wap_labs_import import ImportFailure, MAX_INPUT_JSON, import_wapcurl, safe_url

TIMEOUT_MS = 5000
PROCESS_TIMEOUT_S = 9

class RunFailure(Exception):
    pass


def validate_request(mode: str, url: str, gateway: str | None) -> tuple[str, list[str]]:
    """Return normalized gateway (if any), and command args for upstream wapcurl."""
    safe_url(url)
    scheme = urlsplit(url).scheme
    if mode == 'direct':
        if scheme not in {'http', 'https'} or gateway is not None:
            raise RunFailure('Direct mode requires HTTP(S) resource and no gateway')
        return '', ['--json', '--timeout-ms', str(TIMEOUT_MS), '--retry', '0', url]
    if mode != 'native' or scheme not in {'wap', 'waps'}:
        raise RunFailure('Native mode requires a wap:// or waps:// resource')
    if not gateway:
        raise RunFailure('Native WSP mode requires an explicitly selected gateway')
    normalized_gateway = gateway if '://' in gateway else 'wap://' + gateway
    safe_url(normalized_gateway)
    parsed = urlsplit(normalized_gateway)
    if parsed.scheme not in {'wap', 'waps'} or parsed.path not in {'', '/'} or parsed.query:
        raise RunFailure('Native gateway must be a WAP host:port, without path/query')
    return normalized_gateway, [
        '--profile', 'wap-net-core', '--gateway', gateway,
        '--json', '--timeout-ms', str(TIMEOUT_MS), '--retry', '0', url,
    ]


def run_once(wapcurl: Path, url: str, *, mode: str, gateway: str | None,
             out: Path, allow_fake_binary_for_tests: bool = False) -> dict:
    normalized_gateway, args = validate_request(mode, url, gateway)
    if not wapcurl.is_file() or not os.access(wapcurl, os.X_OK):
        raise RunFailure('wapcurl executable is not available or is not executable')
    if wapcurl.name != 'wapcurl' and not allow_fake_binary_for_tests:
        raise RunFailure('Executable must be named wapcurl (explicit test override only)')
    if out.exists():
        raise RunFailure('Output directory already exists: refusing to overwrite evidence')
    command = [str(wapcurl.resolve()), *args]
    try:
        process = subprocess.run(command, capture_output=True, timeout=PROCESS_TIMEOUT_S, check=False)
    except subprocess.TimeoutExpired as exc:
        raise RunFailure(f'wapcurl process exceeded {PROCESS_TIMEOUT_S}s') from exc
    except OSError as exc:
        raise RunFailure(f'Failed to launch wapcurl: {type(exc).__name__}') from exc
    stdout = process.stdout
    if len(stdout) > MAX_INPUT_JSON:
        raise RunFailure('wapcurl stdout exceeded 2 MiB input limit')
    try:
        decoded = json.loads(stdout.decode('utf-8'))
        record, raw = import_wapcurl(decoded)
    except (UnicodeDecodeError, json.JSONDecodeError, ImportFailure, ValueError) as exc:
        raise RunFailure(f'Invalid or unverifiable wapcurl JSON: {exc}') from exc

    if record['requested_url'] != url:
        raise RunFailure('Requested URL in JSON differs from submitted URL')
    if record['transport'] != ('http' if mode == 'direct' else 'wsp-connectionless/wdp-udp'):
        raise RunFailure('WAP Labs reported unexpected transport')
    if mode == 'native' and record['gateway'] != normalized_gateway:
        raise RunFailure('WAP Labs returned a gateway different from the selected one')
    if mode == 'direct' and record['gateway'] is not None:
        raise RunFailure('Unexpected gateway in direct HTTP result')
    if process.returncode == 0 and not record['upstream_ok']:
        raise RunFailure('Exit status indicated success but JSON reports a failure')
    if process.returncode != 0 and record['upstream_ok']:
        raise RunFailure('Exit status indicated failure but JSON reports success')

    out.mkdir(parents=True, exist_ok=False)
    (out/'wapcurl_stdout.json').write_bytes(stdout)  # immutable source bytes
    (out/'raw_response.bin').write_bytes(raw)
    (out/'report.json').write_text(json.dumps(record, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    summary = {
        'collector': 'wapcurl_runner_r5',
        'source_authenticated': False,
        'user_initiated_single_request': True,
        'mode': mode,
        'requested_url': url,
        'selected_gateway': normalized_gateway or None,
        'wapcurl_exit_code': process.returncode,
        'wapcurl_stdout_sha256': hashlib.sha256(stdout).hexdigest(),
        'response_sha256': hashlib.sha256(raw).hexdigest(),
        'response_bytes': len(raw),
        'stderr_sha256': hashlib.sha256(process.stderr).hexdigest(),
        'stderr_stored': False,
        'origin_wml_grade': record['origin_wml_grade'],
        'gateway_result_cannot_verify_origin_http': mode == 'native',
        'rust_wapcurl_executable_used': str(wapcurl.resolve()),
        'limitations': [
            'External binary identity is not independently attested.',
            'Web origin and collection provenance require separate corroboration.',
            'WAP gateway service can transcode the requested site.',
            'No automatic A grade is assigned to the HTTP origin.',
        ],
    }
    (out/'execution.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    (out/'README.txt').write_text(
        'Capture output from a single explicitly requested URL.\n'
        'wapcurl_stdout.json: original stdout bytes, unaltered.\n'
        'raw_response.bin: bytes decoded from stdout Base64.\n'
        'report.json: independent parser conclusion.\n'
        'execution.json: execution metadata and SHA256 values.\n'
        'Never publish the capture before reviewing private content and ownership.\n',
        encoding='utf-8',
    )
    return summary


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='One-shot wapcurl/WAP Labs capture + independent WAP Probe import')
    parser.add_argument('--wapcurl', type=Path, required=True, help='Path to compiled upstream wapcurl')
    parser.add_argument('--mode', choices=['native', 'direct'], required=True)
    parser.add_argument('--url', required=True, help='Explicit public resource URL')
    parser.add_argument('--gateway', help='Required for native WSP, forbidden for direct HTTP')
    parser.add_argument('--out', type=Path, required=True, help='Must be a new empty destination path')
    args = parser.parse_args(argv)
    try:
        summary = run_once(args.wapcurl, args.url, mode=args.mode, gateway=args.gateway, out=args.out)
    except (RunFailure, ImportFailure) as exc:
        parser.exit(2, f'Cannot complete WAP capture: {exc}\n')
    print('Captured:', args.out)
    print('Bytes:', summary['response_bytes'], 'SHA256:', summary['response_sha256'])
    print('Original HTTP WML status:', summary['origin_wml_grade'])
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
