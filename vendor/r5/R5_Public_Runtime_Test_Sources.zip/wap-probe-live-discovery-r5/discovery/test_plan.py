import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import plan_current_probes as p

REG = Path(__file__).with_name('active_services.csv')

class PlanTests(unittest.TestCase):
    def test_registry_valid(self):
        self.assertGreaterEqual(len(p.parse_registry(REG)),12)
    def test_real_plan_has_no_proxy_or_login(self):
        plan=p.make_plan(p.parse_registry(REG))
        self.assertTrue(plan['queued'])
        self.assertFalse(any('15pmm01' in v['url'] for v in plan['queued']))
        self.assertFalse(any('superbasic-im' in v['url'] for v in plan['queued']))
    def test_excludes_directory_only(self):
        plan=p.make_plan(p.parse_registry(REG))
        self.assertFalse(any(v['name']=='Storydragon' for v in plan['queued']))
    def test_excludes_prior_verified_reference(self):
        plan=p.make_plan(p.parse_registry(REG))
        self.assertFalse(any(v['name']=='BS0DD' for v in plan['queued']))
    def test_no_false_verifications(self):
        plan=p.make_plan(p.parse_registry(REG))
        self.assertEqual(plan['network_requests_performed'],0)
        self.assertTrue(all(v['origin_wml_verified'] is False for v in plan['queued']))
    def test_url_safety(self):
        for url in ('http://localhost','http://127.0.0.1/','http://192.168.0.1',
                    'http://198.18.0.1/','https://x.local/','https://user:pwd@a.com/',
                    'https://example.com:9000/','javascript:alert(1)', 'https://example.com/#fragment'):
            with self.subTest(url=url):self.assertFalse(p.url_ok(url))
        self.assertTrue(p.url_ok('http://find.bevelgacom.be/'))
    def test_duplicate_name_rejected(self):
        rows=p.parse_registry(REG)
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'x.csv'
            with path.open('w',newline='',encoding='utf-8') as fp:
                w=csv.DictWriter(fp,fieldnames=p.FIELDS);w.writeheader();w.writerows(rows+[rows[0]])
            with self.assertRaises(ValueError):p.parse_registry(path)
    def test_empty_row_rejected(self):
        rows=p.parse_registry(REG)
        rows[0]['source']=''
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'x.csv'
            with path.open('w',newline='',encoding='utf-8') as fp:
                w=csv.DictWriter(fp,fieldnames=p.FIELDS);w.writeheader();w.writerows(rows)
            with self.assertRaises(ValueError):p.parse_registry(path)
    def test_outputs(self):
        plan=p.make_plan(p.parse_registry(REG))
        with tempfile.TemporaryDirectory() as d:
            p.write_plan(plan,Path(d))
            j=json.loads((Path(d)/'current_probe_queue.json').read_text())
            self.assertEqual(j['totals']['queued'],len((Path(d)/'current_probe_urls.txt').read_text().splitlines()))
    def test_ordering(self):
        q=p.make_plan(p.parse_registry(REG))['queued']
        self.assertEqual([r['priority'] for r in q],sorted(r['priority'] for r in q))
    def test_2026_projects_dont_become_a_by_association(self):
        plan=p.make_plan(p.parse_registry(REG))
        self.assertTrue(all(r['state'].startswith('U_') for r in plan['queued']))

if __name__=='__main__':unittest.main()
