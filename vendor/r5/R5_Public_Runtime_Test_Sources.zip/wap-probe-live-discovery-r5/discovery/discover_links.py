#!/usr/bin/env python3
"""Read-only link inventory from independently replayable WML HTTP captures.

No network requests, no crawling, no trust in collector-origin metadata. The
SHA-256 hash only authenticates bytes relative to the evidence manifest, NOT
against a remote server. Domain ownership and activity must be checked later.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import urldefrag, urljoin, urlsplit
from zipfile import ZipFile

BASE_DIR = Path(__file__).resolve().parents[1]
PROBE_PATH = BASE_DIR / 'probe'
sys.path.insert(0, str(PROBE_PATH))
import wap_probe  # noqa: E402

PREFIX = 'deepseek_review/evidence/'
WALKS = ('live_walk_bs0dd', 'live_walk_kannel')
MAX_MEMBER_BYTES = 262144


def read_member(z: ZipFile, name: str) -> bytes:
    if name not in z.namelist():
        raise ValueError(f'Missing ZIP member: {name}')
    info = z.getinfo(name)
    if info.file_size > MAX_MEMBER_BYTES:
        raise ValueError(f'Oversize ZIP member: {name}')
    return z.read(name)


def normalized_http_url(base: str, href: str) -> tuple[str, str] | None:
    """Return (URL without fragment, fragment) only for inspectable public URLs."""
    if not isinstance(href, str) or len(href) > 2048:
        return None
    href = href.strip()
    if not href or '$(' in href or '#' == href:
        return None  # variables require evaluation, bare # carries no navigation
    if href.lower().startswith(('javascript:', 'data:', 'file:', 'mailto:')):
        return None
    target = urljoin(base, href)
    target, fragment = urldefrag(target)
    try:
        u = urlsplit(target)
        host = (u.hostname or '').rstrip('.').lower()
        if (host == 'localhost' or host.endswith('.localhost') or
                host.endswith('.local') or host.endswith('.internal')):
            return None
        wap_probe.public_url(target, check_dns=False)
        if u.username or u.password or u.port not in (None, 80, 443):
            return None
    except (ValueError, TypeError):
        return None
    return target, fragment


def origin(url: str) -> tuple:
    u = urlsplit(url)
    return (u.scheme.lower(), u.hostname.lower(), u.port or (443 if u.scheme == 'https' else 80))


def harvest(source_url: str, analysis: dict, digest: str, evidence_path: str) -> list[dict]:
    if analysis['format'] not in ('wml', 'wmlc') or not analysis.get('cards'):
        return []
    result = []
    seen = set()
    bare_source, _ = urldefrag(source_url)
    for link in analysis['links']:
        if link.get('method', 'get').lower() != 'get' or link.get('requires_inputs'):
            continue
        parsed = normalized_http_url(bare_source, link.get('href', ''))
        if parsed is None:
            continue
        dest, fragment = parsed
        relation = ('same_deck_card' if dest == bare_source and fragment
                    else 'same_origin' if origin(dest) == origin(source_url) else 'external')
        key = (dest, fragment)
        if key in seen:
            continue
        seen.add(key)
        result.append({'target': dest, 'fragment': fragment, 'relation': relation,
                       'label': link.get('label', '')[:160], 'source': source_url,
                       'source_sha256': digest, 'evidence_member': evidence_path,
                       'target_live_verified': False,
                       'warning': 'Only link presence is evidenced; target not fetched or tested'})
    return result


def inspect_capture_bundle(zip_path: Path) -> dict:
    output = {'collection': zip_path.name,
              'collection_sha256': hashlib.sha256(zip_path.read_bytes()).hexdigest(),
              'provenance': 'externally collected HTTP response bytes, not authenticated origin',
              'network_requests': 0, 'captures': [], 'links': [], 'errors': []}
    with ZipFile(zip_path) as z:
        for site in WALKS:
            prefix = PREFIX + site + '/'
            try:
                walk = json.loads(read_member(z, prefix + 'walk.json'))
            except (ValueError, KeyError, json.JSONDecodeError) as e:
                output['errors'].append(f'{site}: {e}')
                continue
            for f in walk.get('fetches', []):
                sha = f.get('sha256', '')
                member = prefix + 'evidence/' + sha + '.bin'
                try:
                    body = read_member(z, member)
                    actual_sha = hashlib.sha256(body).hexdigest()
                    if actual_sha != sha:
                        raise ValueError('Evidence SHA256 mismatch')
                    parsed = wap_probe.inspect_markup(body, f.get('content_type', ''))
                    grade = wap_probe.grade({'status': f.get('http_status'), 'redirects': [],
                                             'analysis': parsed})[0]
                    valid = grade.startswith('A-')
                    output['captures'].append({'site': site, 'url': f['url'], 'sha256': sha,
                        'status': f.get('http_status'), 'grade': grade,
                        'body_integrity': True, 'cards': len(parsed.get('cards', [])),
                        'source_claim': 'local DeepSeek collection 2026-10-28'})
                    if valid:
                        output['links'].extend(harvest(f['url'], parsed, sha, member))
                except (ValueError, KeyError, TypeError) as e:
                    output['errors'].append(f'{member}: {e}')
    count = Counter(x['relation'] for x in output['links'])
    output['summary'] = {'verified_hash_captures': len(output['captures']),
                         'extracted_links': len(output['links']),
                         'internal_cards': count['same_deck_card'],
                         'same_origin_links': count['same_origin'],
                         'external_links': count['external']}
    return output


def export_inventory(data: dict, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    (out / 'live_link_inventory.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    # External links are merely tentative candidates. Do not turn all links into scan jobs.
    external = [x for x in data['links'] if x['relation'] == 'external']
    with (out / 'external_link_candidates.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['target', 'source', 'label', 'source_sha256',
                                                'target_live_verified', 'warning'])
        writer.writeheader()
        for x in external:
            writer.writerow({key: x[key] for key in writer.fieldnames})
    (out / 'summary.md').write_text('\n'.join([
        '# Current WML capture link discovery', '',
        '**No live HTTP requests are performed by this script.** The evidence is derived from externally collected captures.',
        'Their hashes were checked against their own metadata; this does not authenticate server origin or timestamps.',
        '', f"- Captured pages with matching SHA256: {data['summary']['verified_hash_captures']}",
        f"- Distinct source-relative links: {data['summary']['extracted_links']}",
        f"- Same-deck card links: {data['summary']['internal_cards']}",
        f"- Same-origin page links: {data['summary']['same_origin_links']}",
        f"- External candidates: {data['summary']['external_links']}",
        f"- Processing errors: {len(data['errors'])}",
        '', '## Discovered external links (NOT verified live)', '',
        *([f"- `{x['target']}` from `{x['source']}`" for x in external] or ['None']),
        '', '## Interpretation', '',
        'References from a current WML page are leads, not evidence that destination sites remain online, WML-capable, safe, or current.',
        'Inspect ownership and robots policy before targeted single-URL probing. Do not crawl URLs from captured pages without approval.',
        '']) + '\n', encoding='utf-8')


def main() -> int:
    p = argparse.ArgumentParser(description='Extract provenance-linked URL candidates from archived WML captures without networking')
    p.add_argument('--review-zip', type=Path, required=True)
    p.add_argument('--out', type=Path, default=Path('reports/live_discovery'))
    args = p.parse_args()
    data = inspect_capture_bundle(args.review_zip)
    export_inventory(data, args.out)
    print(json.dumps(data['summary'], ensure_ascii=False))
    return int(bool(data['errors']))


if __name__ == '__main__':
    raise SystemExit(main())
