#!/usr/bin/env python3
"""Create a bounded, evidence-aware CURRENT WML probe queue; NEVER makes requests.

Only maintainer-advertised WML sites and MIME-confirmed HTTP endpoints are queued.
Community/directory references and historic URLs stay in research-only list.
Gateway converters, login-only apps and emulators are *not* origin WML sites.
"""
from __future__ import annotations

import argparse
import csv
import json
import ipaddress
import re
from collections import Counter
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
ALLOWED_KINDS = {'origin_candidate', 'legacy_xhtml_control', 'verified_reference',
                 'gateway_infrastructure', 'software_no_public_endpoint', 'testing_infrastructure'}
QUEUEABLE_KINDS = {'origin_candidate'}
TRUSTED_SOURCES = {'active_project', 'mime_observation'}
FIELDS = ('name', 'region', 'url', 'kind', 'source', 'source_type', 'first_party',
          'discovered_2026', 'priority', 'state', 'notes')


def url_ok(url: str) -> bool:
    if not url or any(ord(ch) <= 32 for ch in url):
        return False
    try:
        u = urlsplit(url)
        if u.scheme not in {'http', 'https'} or not u.hostname or u.username or u.password or u.fragment:
            return False
        if u.port not in {None, 80, 443}:
            return False
        host = u.hostname.rstrip('.').lower()
        if host in {'localhost'} or host.endswith(('.local', '.internal', '.localhost')):
            return False
        try:
            return ipaddress.ip_address(host).is_global
        except ValueError:
            return bool(re.fullmatch(r'[a-z0-9][a-z0-9.-]*[a-z0-9]', host) and '.' in host)
    except ValueError:
        return False


def parse_registry(path: Path) -> list[dict[str, str]]:
    with path.open(encoding='utf-8', newline='') as stream:
        reader = csv.DictReader(stream)
        if tuple(reader.fieldnames or ()) != FIELDS:
            raise ValueError('Unexpected registry field layout')
        rows = list(reader)
    names = set()
    for row in rows:
        if not all(row.get(key) for key in FIELDS):
            raise ValueError(f'Incomplete registry record: {row.get("name")}')
        if row['name'] in names:
            raise ValueError('Duplicate registry name')
        names.add(row['name'])
        if row['kind'] not in ALLOWED_KINDS or row['first_party'] not in {'yes', 'no'}:
            raise ValueError(f'Invalid kind or source identity for {row["name"]}')
        if row['discovered_2026'] not in {'yes', 'no'} or row['priority'] not in {'1','2','3'}:
            raise ValueError(f'Invalid year marker or priority for {row["name"]}')
        if not url_ok(row['url']) or not url_ok(row['source']):
            raise ValueError(f'Invalid URL for {row["name"]}')
    return rows


def make_plan(rows: list[dict[str,str]]) -> dict:
    queued, excluded = [], []
    seen_urls = set()
    for r in rows:
        reason = None
        if r['kind'] not in QUEUEABLE_KINDS:
            reason = f'{r["kind"]}: never automatically treat this as a direct WML service'
        elif r['source_type'] not in TRUSTED_SOURCES:
            reason = 'Only referenced by directory; requires separate current ownership review'
        elif r['first_party'] != 'yes':
            reason = 'No first-party deployment verification'
        elif r['state'] not in {'U_no_original_body', 'U_mime_only'}:
            reason = 'Already classified, blocked, or unsupported evidence status'
        elif r['url'] in seen_urls:
            reason = 'Duplicate URL'
        if reason:
            excluded.append({'name':r['name'], 'url':r['url'], 'reason':reason})
            continue
        seen_urls.add(r['url'])
        queued.append({'name':r['name'], 'region':r['region'], 'url':r['url'],
                       'source':r['source'], 'priority':int(r['priority']),
                       'state':r['state'], 'profiles':['wap1','s60'],
                       'review_current_ownership':True, 'requests_scheduled':0,
                       'origin_wml_verified':False})
    queued.sort(key=lambda r:(r['priority'], r['name']))
    return {'policy':'direct-origin WML probes only; never test proxy-converted output as origin support',
            'network_requests_performed':0, 'queued':queued, 'excluded':excluded,
            'totals':{'registry':len(rows),'queued':len(queued),'excluded':len(excluded)},
            'regions':dict(Counter(r['region'] for r in queued))}


def write_plan(plan: dict, out: Path):
    out.mkdir(parents=True,exist_ok=True)
    (out/'current_probe_queue.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    (out/'current_probe_urls.txt').write_text('\n'.join(r['url'] for r in plan['queued'])+'\n',encoding='utf-8')
    (out/'not_origin_sites.json').write_text(json.dumps(plan['excluded'],indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    lines = [
        '# Current WML candidate probe plan', '',
        '**This planner performs ZERO HTTP requests.** No queued origin is newly verified by the generated files.',
        '', f"- Registry records: {plan['totals']['registry']}",
        f"- Explicitly queued direct-origin WML candidates: {plan['totals']['queued']}",
        f"- Excluded from automated direct-origin checking: {plan['totals']['excluded']}",
        '', '## Read-only manual review queue', '',
    ]
    for n, r in enumerate(plan['queued'],1):
        lines.append(f"{n}. `{r['url']}` — {r['name']} (priority {r['priority']}; {r['state']})")
    lines.extend(['','## Evidence interpretation', '',
                  '- Only a successful direct GET with validated WML/WMLC bytes and matching MIME can support grade A.',
                  '- A maintained GitHub project or a directory listing is NOT itself live WML verification.',
                  '- Historic/redirected modern HTML, gateway-transcoded WML, login-only sites, and emulators are not origin A.',
                  '- Verify site ownership, robots and current use before probing. Do not crawl or log in.',
                  '- When running v0.3.3 on an internet-capable machine, run a **small reviewed batch** with 1.2 s or more delay.',
                  '- Never add the gateway port 9201 or third-party HTTP proxy as if it were an ordinary website.',
                  ''])
    (out/'queue_summary.md').write_text('\n'.join(lines),encoding='utf-8')


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--registry',type=Path,default=ROOT/'active_services.csv')
    p.add_argument('--out',type=Path,default=ROOT.parent/'reports'/'current_plan')
    a=p.parse_args(argv)
    plan=make_plan(parse_registry(a.registry))
    write_plan(plan,a.out)
    print(json.dumps(plan['totals'],ensure_ascii=False))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
