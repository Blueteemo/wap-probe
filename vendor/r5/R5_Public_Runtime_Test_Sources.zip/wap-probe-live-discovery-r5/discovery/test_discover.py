import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import discover_links as d


class DiscoverTests(unittest.TestCase):
    def test_same_deck(self):
        self.assertEqual(d.normalized_http_url('https://foo.example/main.wml', '#next'),
                         ('https://foo.example/main.wml', 'next'))

    def test_relative_url(self):
        self.assertEqual(d.normalized_http_url('https://foo.example/a/main.wml', 'page.wml#b'),
                         ('https://foo.example/a/page.wml', 'b'))

    def test_block_dynamic_or_non_http(self):
        for href in ('$(url)', 'javascript:alert(1)', 'file:///etc/passwd',
                     'http://127.0.0.1/', 'http://192.168.1.6/',
                     'https://localhost./', 'https://x.localhost/'):
            with self.subTest(href=href):
                self.assertIsNone(d.normalized_http_url('https://foo.example/a', href))

    def test_no_post_or_input_submission(self):
        a = {'format': 'wml', 'cards':[{'id': 'x'}],
             'links': [{'href': '#abc', 'method': 'post'},
                       {'href':'https://public.example/test','method':'get','requires_inputs':True},
                       {'href':'ok.wml','method':'get'}]}
        result = d.harvest('https://foo.example/start', a, 'abc', 'sample')
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['target'], 'https://foo.example/ok.wml')
        self.assertEqual(result[0]['relation'], 'same_origin')

    def test_unverified_formats_not_harvested(self):
        a = {'format':'html', 'cards':[{'id':'x'}], 'links':[{'href':'http://evil.example/'}]}
        self.assertEqual(d.harvest('https://foo.example', a, 'a', 'sample'), [])

    def test_real_legacy_capture_inventory(self):
        z = Path(__file__).resolve().parents[1] / 'probe/research/deepseek_review_original.zip'
        if not z.exists():
            self.skipTest('External HTTP research captures preserved in private backup')
        result = d.inspect_capture_bundle(z)
        self.assertEqual(result['errors'], [])
        self.assertEqual(result['summary']['verified_hash_captures'], 4)
        self.assertEqual(result['summary']['external_links'], 1)
        self.assertFalse(any(x['target_live_verified'] for x in result['links']))

    def test_export_does_not_claim_live(self):
        result = {'collection':'x', 'links':[], 'errors':[],
                  'summary':{'verified_hash_captures':0,'extracted_links':0,
                             'internal_cards':0,'same_origin_links':0,'external_links':0}}
        with tempfile.TemporaryDirectory() as tmp:
            d.export_inventory(result,Path(tmp))
            self.assertEqual(json.loads((Path(tmp)/'live_link_inventory.json').read_text())['links'],[])
            self.assertEqual(len((Path(tmp)/'external_link_candidates.csv').read_text().splitlines()),1)


if __name__ == '__main__':
    unittest.main()
