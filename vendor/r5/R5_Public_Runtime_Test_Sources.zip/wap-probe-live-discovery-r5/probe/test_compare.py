import json
from pathlib import Path
import tempfile
import unittest
import wap_compare as c


def rec(url, profile, *, sha='abc', mime='text/vnd.wap.wml', status=200, grade='A-wml-verified', error=None):
    return {'url':url, 'profile':profile, 'status':status, 'sha256':sha, 'content_type':mime,
            'analysis':{'mime':mime,'format':'wml'}, 'grade':grade,'error':error}

class ComparisonTests(unittest.TestCase):
    def test_identical_responses_do_not_prove_content_negotiation(self):
        pairs = c.compare([rec('http://test.example','wap1'), rec('http://test.example','s60')])
        self.assertEqual(pairs[0]['outcome'],'same_response_bytes_and_mime')
        self.assertFalse(pairs[0]['wap1']['live_verified'])

    def test_different_responses_not_automatic_compatibility(self):
        pairs = c.compare([rec('http://test.example','wap1'), rec('http://test.example','s60',sha='def')])
        self.assertEqual(pairs[0]['outcome'],'different_observed_response')
        self.assertIn('no handset compatibility',pairs[0]['interpretation'])

    def test_missing_or_dns_failure_is_inconclusive(self):
        pairs = c.compare([rec('http://test.example','wap1',sha=None,error='DNS error'),
                           rec('http://test.example','s60')])
        self.assertEqual(pairs[0]['outcome'],'inconclusive')
        self.assertEqual(c.compare([rec('http://test.example','wap1')])[0]['outcome'],'insufficient_profiles')

    def test_load_imported_and_direct_report_formats(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            p1=root/'one.json';p2=root/'two.json'
            p1.write_text(json.dumps({'record':rec('http://test.example','wap1')}))
            p2.write_text(json.dumps({'records':[rec('http://test.example','s60')]}))
            loaded=c.load_records([p1,p2])
            self.assertEqual(len(loaded),2)
            self.assertEqual(c.compare(loaded)[0]['outcome'],'same_response_bytes_and_mime')

    def test_duplicate_profile_is_rejected_not_silently_overwritten(self):
        with self.assertRaisesRegex(ValueError,'Duplicate URL/profile'):
            c.compare([rec('http://test.example','wap1'),rec('http://test.example','wap1',sha='changed')])

    def test_cli_writes_comparison(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            r=root/'capture.json'
            r.write_text(json.dumps({'records':[rec('http://test.example','wap1'),rec('http://test.example','s60')]}))
            self.assertEqual(c.main([str(r),'--out',str(root/'comparison')]),0)
            result=json.loads((root/'comparison'/'comparison.json').read_text())
            self.assertEqual(result['pairs'][0]['outcome'],'same_response_bytes_and_mime')

if __name__=='__main__':
    unittest.main()
