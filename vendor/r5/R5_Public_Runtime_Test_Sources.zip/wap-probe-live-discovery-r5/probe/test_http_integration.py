"""Real local-loopback HTTP fetches; public_url patched ONLY within tests.

All HTTP endpoints are provided by this process. No public domains contacted.
"""
from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from unittest.mock import patch
import unittest

import wap_probe as p
import wap_browser as b

F = Path(__file__).resolve().parent / 'fixtures'
WML = (F/'portal.wml').read_bytes()
WMLC = (F/'binary_portal.wmlc').read_bytes()
HTML = (F/'sample_html.html').read_bytes()

class Handler(BaseHTTPRequestHandler):
    request_headers: list[tuple[str, str]] = []
    def do_GET(self):
        self.request_headers.append((self.path,self.headers.get('Accept','')))
        if self.path == '/start.wml':
            body, mime, status = WML, 'text/vnd.wap.wml; charset=utf-8', 200
        elif self.path == '/posts.wml':
            body, mime, status = (F/'posts.wml').read_bytes(), 'text/vnd.wap.wml', 200
        elif self.path == '/binary.wmlc':
            body, mime, status = WMLC, 'application/vnd.wap.wmlc', 200
        elif self.path == '/bad-redirect':
            self.send_response(302)
            self.send_header('Location','/modern')
            self.end_headers()
            return
        elif self.path == '/redirect-outside':
            self.send_response(302)
            self.send_header('Location','https://example.com/')
            self.end_headers()
            return
        elif self.path == '/modern':
            body, mime, status = HTML, 'text/html', 200
        else:
            body, mime, status = b'gone', 'text/plain', 404
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


class HTTPIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        Handler.request_headers = []
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.port = cls.server.server_port
        cls.thread = Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def test_probe_wml_over_http(self):
        with patch.object(p,'public_url'):
            r,data = p.probe(self.base+'/start.wml','wap1',2,300000)
        self.assertEqual(r['status'],200)
        self.assertEqual(r['grade'],'A-wml-verified')
        self.assertEqual(len(data),len(WML))

    def test_probe_binary_wml_over_http(self):
        with patch.object(p,'public_url'):
            r,data = p.probe(self.base+'/binary.wmlc','wap1',2,300000)
        self.assertEqual(r['grade'],'A-wmlc-verified')
        self.assertEqual(r['analysis']['cards'][1]['id'],'next')

    def test_real_http_navigation_two_documents(self):
        with patch.object(p,'public_url'):
            nav = b.WAPNavigator(self.base+'/start.wml',profile='wap1',delay=0)
            nav.choose(1)
            nav.choose(1)
            nav.choose(1)
        self.assertEqual(len(nav.fetches),2)
        self.assertEqual(len(nav.events),4)
        self.assertEqual(nav.snapshot()['card_id'],'post1')
        self.assertIn('WML 卡片',nav.snapshot()['text'])

    def test_real_http_binary_navigation(self):
        with patch.object(p,'public_url'):
            nav = b.WAPNavigator(self.base+'/binary.wmlc',profile='wap1')
            nav.choose(1)
        self.assertEqual(nav.snapshot()['card_id'],'next')
        self.assertEqual(nav.snapshot()['format'],'wmlc')

    def test_modern_html_rejected(self):
        with patch.object(p,'public_url'):
            r,_ = p.probe(self.base+'/modern','wap1',2,300000)
            self.assertEqual(r['grade'],'C-html-only')
            with self.assertRaisesRegex(ValueError,'not verified'):
                b.WAPNavigator(self.base+'/modern',profile='wap1')

    def test_modern_redirect_flag(self):
        with patch.object(p,'public_url'):
            r,_ = p.probe(self.base+'/bad-redirect','wap1',2,300000)
        self.assertEqual(r['grade'],'D-modern-redirect-candidate')
        self.assertEqual(len(r['redirects']),1)

    def test_cross_origin_redirect_blocked(self):
        # No external request can execute: SafeRedirect checks public_url and same origin.
        with patch.object(p,'public_url'):
            r,_ = p.probe(self.base+'/redirect-outside','wap1',2,300000,allowed_origin=self.base)
        self.assertIsNotNone(r['error'])
        self.assertEqual(r['grade'],'U-inconclusive')

    def test_request_profile_was_transmitted(self):
        with patch.object(p,'public_url'):
            p.probe(self.base+'/binary.wmlc','wap1',2,300000)
        self.assertTrue(any(path=='/binary.wmlc' and 'application/vnd.wap.wmlc' in accept
                            for path,accept in Handler.request_headers))

if __name__ == '__main__': unittest.main()
