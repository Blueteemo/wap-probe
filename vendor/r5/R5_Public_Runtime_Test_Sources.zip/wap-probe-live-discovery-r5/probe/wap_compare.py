#!/usr/bin/env python3
"""Compare WAP1 and S60 evidence reports without making network requests."""
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

SUPPORTED = {'wap1','s60'}


def load_records(paths: list[Path]) -> list[dict]:
    records = []
    for path in paths:
        obj = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(obj, dict):
            raise ValueError(f'{path}: expected JSON object')
        source = obj.get('records')
        if source is None:
            source = [obj['record']] if 'record' in obj else None
        if not isinstance(source, list):
            raise ValueError(f'{path}: missing report record(s)')
        for record in source:
            if not isinstance(record, dict) or not record.get('url') or record.get('profile') not in SUPPORTED:
                raise ValueError(f'{path}: invalid record URL/profile')
            records.append(record)
    return records


def compact(r: dict) -> dict:
    return {'status':r.get('status'), 'grade':r.get('grade'),
            'mime':r.get('analysis',{}).get('mime') or r.get('content_type'),
            'format':r.get('analysis',{}).get('format'),
            'sha256':r.get('sha256'), 'final_url':r.get('final_url'),
            'error':r.get('error'),
            'source':r.get('evidence_origin','direct_or_unspecified'),
            'live_verified':bool(r.get('live_verified',False))}


def compare(records: list[dict]) -> list[dict]:
    groups = defaultdict(dict)
    for r in records:
        if r['profile'] in groups[r['url']]:
            raise ValueError(f"Duplicate URL/profile capture; select one explicit observation: {r['url']} {r['profile']}")
        groups[r['url']][r['profile']] = r
    results = []
    for url in sorted(groups):
        slots = groups[url]
        left = compact(slots['wap1']) if 'wap1' in slots else None
        right = compact(slots['s60']) if 's60' in slots else None
        outcome = 'insufficient_profiles'
        if left and right:
            if (left['error'] or right['error'] or left['status'] is None or
                right['status'] is None or not left['sha256'] or not right['sha256']):
                outcome = 'inconclusive'
            elif (left['sha256']==right['sha256'] and left['mime']==right['mime']
                  and left['status']==right['status']):
                outcome = 'same_response_bytes_and_mime'
            else:
                outcome = 'different_observed_response'
        results.append({'url':url,'outcome':outcome,'wap1':left,'s60':right,
                        'interpretation':'Differences can be caused by User-Agent, server changes, redirects or differing capture times; no handset compatibility inference.'})
    return results


def main(argv=None):
    parser = argparse.ArgumentParser(description='Compare WAP1 / S60 HTTP evidence JSON (offline)')
    parser.add_argument('reports',nargs='+',type=Path,help='Direct probe or imported capture report.json')
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args(argv)
    try:
        records = load_records(args.reports)
        comparison = compare(records)
    except (ValueError, KeyError, OSError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/'comparison.json').write_text(json.dumps({'pairs':comparison},ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# WAP profile comparison','',
           'This is evidence comparison, **not** a confirmed handset compatibility test.','',
           '| URL | WAP1 | S60 | Outcome |','|---|---|---|---|']
    for pair in comparison:
        a,b=pair['wap1'],pair['s60']
        lines.append(f"| `{pair['url'].replace('|','%7C')}` | {a['grade'] if a else '—'} | {b['grade'] if b else '—'} | {pair['outcome']} |")
    lines+=['','Imported captures are **not independently authenticated**; check collection dates and metadata before drawing conclusions.']
    (args.out/'comparison.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    for p in comparison:
        print(p['outcome'], p['url'])
    return 0

if __name__=='__main__':
    raise SystemExit(main())
