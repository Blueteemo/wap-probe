"""Offline re-validation of evidence that was captured by another machine."""
import unittest
from pathlib import Path

from wap_replay import analyze_archive

SOURCE=Path(__file__).parent/'research'/'deepseek_review_original.zip'


@unittest.skipUnless(SOURCE.exists(), 'The external evidence archive is not bundled')
class EvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report=analyze_archive(SOURCE)

    def test_manifest_41_files(self):
        self.assertEqual(self.report['integrity']['checked'],41)
        self.assertEqual(self.report['integrity']['failures'],[])

    def test_23_captured_responses_reclassify_identically(self):
        items=[x for x in self.report['replayed'] if 'match' in x]
        self.assertEqual(len(items),23)
        self.assertTrue(all(x['match'] for x in items))

    def test_two_a_endpoints_in_original_captures(self):
        grades={x['url']:x['replayed_grade'] for x in self.report['replayed']
                if 'replayed_grade' in x}
        self.assertEqual(grades['https://wap.bs0dd.net/'],'A-wml-verified')
        self.assertEqual(grades['https://www.kannel.org/wap/main.wml'],'A-wml-verified')

    def test_two_live_traces_have_four_verified_captures(self):
        self.assertEqual(len(self.report['walks']),2)
        checks=[x for walk in self.report['walks'] for x in walk['fetches']]
        self.assertEqual(len(checks),4)
        self.assertTrue(all(x['sha256_match'] and x['matches_collector'] for x in checks))

    def test_no_external_network_invoked(self):
        self.assertFalse(self.report['authenticated_live_fetch'])
        self.assertEqual(self.report['errors'],[])


if __name__=='__main__':
    unittest.main()
