"""Security regression: Clash/Mihomo fake-IP compatibility is explicit, DNS-only."""
import unittest
import urllib.request
from unittest.mock import patch

import wap_probe as p


def dns(address):
    return [(2, 1, 6, '', (address, 443))]


class FakeIPTests(unittest.TestCase):
    def test_default_fails_closed(self):
        with patch.object(p.socket,'getaddrinfo',return_value=dns('198.18.0.2')):
            with self.assertRaisesRegex(ValueError,'private/reserved'):
                p.public_url('https://wap.example.org/')

    def test_opt_in_permits_dns_fake_ip_only(self):
        with patch.object(p.socket,'getaddrinfo',return_value=dns('198.18.0.2')):
            p.public_url('https://wap.example.org/',allow_tun_fake_ip=True)

    def test_benchmark_literal_rejected_with_opt_in(self):
        for url in ('http://198.18.0.2/', 'http://198.19.255.254/'):
            with self.subTest(url=url), self.assertRaisesRegex(ValueError, 'blocked'):
                p.public_url(url, check_dns=False, allow_tun_fake_ip=True)

    def test_private_addresses_remain_blocked(self):
        for addr in ('10.0.0.3', '192.168.0.10', '127.0.0.1', '169.254.1.1', '::1'):
            with self.subTest(addr=addr), patch.object(p.socket,'getaddrinfo',return_value=dns(addr)):
                with self.assertRaises(ValueError):
                    p.public_url('https://wap.example.org/',allow_tun_fake_ip=True)

    def test_mixed_dns_answer_remains_blocked(self):
        addresses=dns('198.18.0.10')+dns('192.168.5.4')
        with patch.object(p.socket,'getaddrinfo',return_value=addresses):
            with self.assertRaisesRegex(ValueError, 'private/reserved'):
                p.public_url('https://wap.example.org/',allow_tun_fake_ip=True)

    def test_fake_ip_redirect_still_rejects_private_destination(self):
        redirect=p.SafeRedirect([],allow_tun_fake_ip=True)
        req=urllib.request.Request('https://wap.example.org/')
        with self.assertRaises(ValueError):
            redirect.redirect_request(req,None,302,'Found',{},'http://127.0.0.1/private')

    def test_opt_in_remains_disabled_for_new_redirect_handler(self):
        self.assertFalse(p.SafeRedirect([]).allow_tun_fake_ip)


if __name__=='__main__':
    unittest.main()
