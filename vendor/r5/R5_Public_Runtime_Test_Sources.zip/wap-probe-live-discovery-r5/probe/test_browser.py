"""Offline and mock-network tests for WML read-only navigation."""
from __future__ import annotations
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import wap_browser as b
import wap_probe as p

F = Path(__file__).resolve().parent / 'fixtures'


class BrowserTests(unittest.TestCase):
    def test_really_navigates_cards_and_files(self):
        nav = b.WAPNavigator(str(F/'portal.wml'), offline=True)
        self.assertEqual(nav.snapshot()['card_id'], 'home')
        nav.choose(1)
        self.assertEqual(nav.snapshot()['card_id'], 'news')
        nav.choose(1)
        self.assertEqual(nav.snapshot()['card_id'], 'list')
        nav.choose(1)
        self.assertEqual(nav.snapshot()['card_id'], 'post1')
        self.assertIn('WML 卡片', nav.snapshot()['text'])
        self.assertEqual(len(nav.fetches), 2)
        self.assertEqual(len(nav.events), 4)

    def test_go_do_returns_to_home(self):
        nav = b.WAPNavigator(str(F/'portal.wml'), offline=True)
        nav.choose(1)
        nav.choose(2)
        self.assertEqual(nav.snapshot()['card_id'], 'home')

    def test_invalid_card_id_not_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'sample.wml'
            path.write_text('<wml><card id="home"><p><a href="#missing">bad</a></p></card></wml>')
            nav = b.WAPNavigator(str(path), offline=True)
            with self.assertRaisesRegex(ValueError, 'not found'):
                nav.choose(1)

    def test_form_submission_disabled(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'sample.wml'
            path.write_text('''<wml><card id="x"><p><anchor>login<go href="login.wml" method="post"><postfield name="q" value="1"/></go></anchor></p></card></wml>''')
            nav = b.WAPNavigator(str(path), offline=True)
            self.assertTrue(nav.options()[0]['requires_inputs'])
            with self.assertRaisesRegex(ValueError, 'forms'):
                nav.choose(1)

    def test_external_links_not_followed_offline(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'sample.wml'
            path.write_text('<wml><card id="a"><p><a href="https://example.com/">jump</a></p></card></wml>')
            nav = b.WAPNavigator(str(path), offline=True)
            with self.assertRaisesRegex(ValueError, 'cannot use network'):
                nav.choose(1)

    def test_parent_escape_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            parent = Path(d)
            fixture = parent / 'child'
            fixture.mkdir()
            (parent/'private.wml').write_text('<wml><card id="ok"/></wml>')
            path = fixture / 'portal.wml'
            path.write_text('<wml><card id="a"><p><a href="../private.wml">bad</a></p></card></wml>')
            nav = b.WAPNavigator(str(path), offline=True)
            with self.assertRaisesRegex(ValueError, 'restricted'):
                nav.choose(1)

    def test_missing_remote_card_does_not_change_state(self):
        with tempfile.TemporaryDirectory() as d:
            first = Path(d)/'first.wml'
            second = Path(d)/'second.wml'
            first.write_text('<wml><card id="a"><p><a href="second.wml#missing">bad</a></p></card></wml>')
            second.write_text('<wml><card id="b"><p>valid page</p></card></wml>')
            nav = b.WAPNavigator(str(first), offline=True)
            state = nav.snapshot()
            with self.assertRaisesRegex(ValueError, 'not found'):
                nav.choose(1)
            self.assertEqual(nav.snapshot(), state)
            self.assertEqual(len(nav.events),1)

    def test_wmlc_dynamic_link_is_not_requested(self):
        nav = b.WAPNavigator(str(F/'variable_link.wmlc'),offline=True)
        self.assertIn('$(uid:escape)',nav.options()[0]['href'])
        with self.assertRaisesRegex(ValueError,'variables not supported'):
            nav.choose(1)
        self.assertEqual(len(nav.fetches), 1)

    def test_javascript_link_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'sample.wml'
            path.write_text('<wml><card id="a"><p><a href="javascript:alert(1)">bad</a></p></card></wml>')
            nav = b.WAPNavigator(str(path), offline=True)
            with self.assertRaisesRegex(ValueError, 'cannot use network'):
                nav.choose(1)

    def test_no_external_origin_on_network_navigation(self):
        def fake_probe(url, profile, timeout, max_bytes, allowed_origin=None):
            data = b'<wml><card id="x"><p><a href="https://other.example.net/x">other</a></p></card></wml>'
            ana = p.inspect_markup(data,'text/vnd.wap.wml')
            return {'status':200,'final_url':url,'error':None,'grade':'A-wml-verified',
                    'analysis':ana,'content_type':'text/vnd.wap.wml'}, data
        with patch.object(p,'public_url'), patch.object(p,'probe', side_effect=fake_probe):
            nav = b.WAPNavigator('https://example.com/', offline=False)
            with self.assertRaisesRegex(ValueError, 'External origin'):
                nav.choose(1)

    def test_legacy_profile_does_not_accept_xhtml(self):
        data = (F/'sample_xhtml_mp.xhtml').read_bytes()
        ana = p.inspect_markup(data,'application/vnd.wap.xhtml+xml')
        with patch.object(p,'public_url'),patch.object(p,'probe', return_value=({'status':200,'final_url':'https://example.com/',
                  'error':None,'grade':'B-xhtml-mp-candidate','analysis':ana,'content_type':'application/vnd.wap.xhtml+xml'},data)):
            with self.assertRaisesRegex(ValueError, 'not verified'):
                b.WAPNavigator('https://example.com/', offline=False, profile='wap1')
            nav = b.WAPNavigator('https://example.com/', offline=False, profile='s60')
            self.assertEqual(nav.snapshot()['format'],'xhtml_mp')

    def test_same_origin_matches_default_ports(self):
        self.assertTrue(b.same_origin('http://example.com/x', 'http://example.com:80/y'))
        self.assertFalse(b.same_origin('http://example.com/x', 'https://example.com/y'))


if __name__ == '__main__':
    unittest.main(verbosity=2)
