#!/usr/bin/env python3
"""WAP compatibility probe, v0.3.3. Stdlib only; read-only public-page checks.

It verifies *markup and response headers*, not compatibility with physical phones.
No automatic crawling and no submission of forms or authentication.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import html
from html.parser import HTMLParser
import ipaddress
import json
import re
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

from wap_wbxml import WBXMLDecodeError, decode_wmlc
from datetime import datetime, timezone
from pathlib import Path
from email.message import Message

VERSION = '0.3.3'
MAX_LINKS = 40
PROFILES = {
    'wap1': {
        'User-Agent': 'Nokia7110/1.0 (04.88)',
        'Accept': 'text/vnd.wap.wml,application/vnd.wap.wmlc;q=0.9,*/*;q=0.1',
        'Accept-Language': 'zh-cn,zh;q=0.9,en;q=0.5',
    },
    's60': {
        'User-Agent': 'NokiaE63-1/100.21.110 (SymbianOS/9.2; U; Series60/3.1; Profile/MIDP-2.0 Configuration/CLDC-1.1)',
        'Accept': 'application/vnd.wap.xhtml+xml,application/xhtml+xml;q=0.9,text/html;q=0.8,text/vnd.wap.wml;q=0.6,*/*;q=0.1',
        'Accept-Language': 'zh-cn,zh;q=0.9,en;q=0.5',
    },
}
WML_MIME = {'text/vnd.wap.wml', 'application/vnd.wap.wml+xml'}
WMLC_MIME = {'application/vnd.wap.wmlc','application/vnd.wap.wbxml'}
XHTML_MP_MIME = {'application/vnd.wap.xhtml+xml'}
# RFC 2544: Clash/Mihomo TUN can resolve public hostnames to this benchmark
# range. NEVER permit literal addresses in this range; only opt-in DNS results.
TUN_FAKE_IP_NET = ipaddress.ip_network('198.18.0.0/15')


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def mime_type(raw: str) -> tuple[str, str | None]:
    msg = Message()
    msg['content-type'] = raw or 'application/octet-stream'
    return msg.get_content_type().lower(), msg.get_content_charset()


def localname(tag: str) -> str:
    return tag.rsplit('}', 1)[-1].lower() if isinstance(tag, str) else ''


def public_url(url: str, check_dns: bool = True, *, allow_tun_fake_ip: bool = False) -> None:
    u = urllib.parse.urlsplit(url)
    if u.scheme not in ('http', 'https') or not u.hostname or u.username or u.password:
        raise ValueError('Only public HTTP(S) URLs without embedded credentials are allowed')
    if u.hostname.lower() in ('localhost',) or u.hostname.lower().endswith(('.local', '.internal')):
        raise ValueError('Local/private host blocked')
    if u.port not in (None, 80, 443):
        raise ValueError('Nonstandard port blocked by default')
    is_literal = False
    try:
        literal = ipaddress.ip_address(u.hostname.strip('[]'))
        is_literal = True
        if not literal.is_global:
            raise ValueError('Private/reserved IP blocked')
    except ValueError as exc:
        if 'blocked' in str(exc):
            raise
    if check_dns:
        resolved = socket.getaddrinfo(u.hostname, u.port or (443 if u.scheme == 'https' else 80), type=socket.SOCK_STREAM)
        if not resolved or any(
            not (ipaddress.ip_address(item[4][0]).is_global or
                 (allow_tun_fake_ip and not is_literal and
                  ipaddress.ip_address(item[4][0]) in TUN_FAKE_IP_NET))
            for item in resolved
        ):
            raise ValueError('Host resolves to private/reserved address')


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self, chain: list[dict], allowed_origin: str | None = None, *, allow_tun_fake_ip: bool = False):
        super().__init__()
        self.chain = chain
        self.allowed_origin = allowed_origin
        self.allow_tun_fake_ip = allow_tun_fake_ip
        self.max_redirections = 5
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        public_url(newurl, allow_tun_fake_ip=self.allow_tun_fake_ip)
        if self.allowed_origin is not None:
            one = urllib.parse.urlsplit(self.allowed_origin)
            two = urllib.parse.urlsplit(newurl)
            identity = lambda u: (u.scheme.lower(), u.hostname.lower(), u.port or (443 if u.scheme == 'https' else 80))
            if identity(one) != identity(two):
                raise ValueError('Cross-origin redirect blocked for navigational browsing')
        self.chain.append({'status': code, 'from': req.full_url, 'to': newurl})
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class LinkExtractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links: list[dict] = []
        self._href: str | None = None
        self._buf: list[str] = []
        self.script_count = 0
        self.forms_count = 0
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag.lower() == 'a':
            self._href = attrs.get('href')
            self._buf = []
        elif tag.lower() == 'script':
            self.script_count += 1
        elif tag.lower() == 'form':
            self.forms_count += 1
    def handle_data(self, data):
        if self._href is not None:
            self._buf.append(data)
    def handle_endtag(self, tag):
        if tag.lower() == 'a' and self._href is not None:
            self.links.append({'href': self._href, 'label': ' '.join(''.join(self._buf).split())[:160]})
            self._href = None
            self._buf = []


def decode_body(data: bytes, declared: str | None) -> tuple[str, str]:
    head = data[:350].decode('ascii', errors='ignore')
    xml_decl = re.search(r'<\?xml[^>]*encoding=[\'\"]([^\'\"]+)', head, flags=re.I)
    meta = re.search(r'charset\s*=\s*[\'\"]?([\w-]+)', head, re.I)
    opts = [declared, xml_decl.group(1) if xml_decl else None, meta.group(1) if meta else None,
            'utf-8', 'gb18030', 'big5']
    for enc in dict.fromkeys(x for x in opts if x):
        try:
            return data.decode(enc, errors='strict'), enc
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode('utf-8', errors='replace'), 'utf-8-replacement'


def wml_entity_cleanup(text: str) -> str:
    # Replace only common named HTML entities; XML numeric and core entities are preserved.
    def fix(match):
        name = match.group(1)
        if name in ('amp', 'lt', 'gt', 'quot', 'apos'):
            return match.group(0)
        converted = html.unescape('&' + name + ';')
        return converted if converted != '&' + name + ';' else match.group(0)
    return re.sub(r'&([A-Za-z][A-Za-z0-9]+);', fix, text)


def inspect_markup(body: bytes, content_type: str) -> dict:
    mime, charset = mime_type(content_type)
    result = {'mime': mime, 'charset': None, 'format': 'unknown', 'valid_xml': None,
              'cards': [], 'links': [], 'script_count': 0, 'forms_count': 0,
              'notes': [], 'preview': ''}
    if not body:
        result['notes'].append('Empty body')
        return result
    binary_candidate = mime in WMLC_MIME or (
        len(body) >= 5 and body[0] in (0, 1, 2, 3) and b'<' not in body[:30])
    if binary_candidate:
        result['format'] = 'wbxml_candidate'
        try:
            xml_data, details = decode_wmlc(body)
            inner = inspect_markup(xml_data, 'text/vnd.wap.wml; charset=utf-8')
            result.update(inner)
            result['format'] = 'wmlc'
            result['mime'] = mime  # preserve the actual HTTP MIME, not synthesized XML MIME
            result['charset'] = inner['charset']
            result['wbxml'] = details
            result['notes'].append('WML reconstructed from WBXML; original binary evidence is preserved')
            if details['variable_refs']:
                result['notes'].append(f"{details['variable_refs']} WML variable reference(s) preserved literally, NOT resolved")
        except WBXMLDecodeError as exc:
            result['notes'].append('WBXML not verified: ' + str(exc))
        return result
    text, enc = decode_body(body, charset)
    result['charset'] = enc
    result['preview'] = ' '.join(re.sub(r'<[^>]{0,400}>', ' ', text[:1500]).split())[:350]
    root = None
    if re.search(r'<\s*(?:\w+:)?(?:wml|html)\b', text, flags=re.I):
        try:
            root = ET.fromstring(wml_entity_cleanup(text))
            result['valid_xml'] = True
        except ET.ParseError as exc:
            result['valid_xml'] = False
            result['notes'].append('XML parse error: ' + str(exc)[:150])
    if root is not None and localname(root.tag) == 'wml':
        result['format'] = 'wml'
        for card in root.iter():
            if localname(card.tag) != 'card':
                continue
            card_links = []
            inputs = []
            for e in card.iter():
                name = localname(e.tag)
                if name == 'input':
                    inputs.append({'name': e.get('name'), 'type': e.get('type', 'text')})
                if name == 'a' and e.get('href'):
                    card_links.append({'href': e.get('href'), 'label': ' '.join(' '.join(e.itertext()).split())[:160],
                                       'method': 'get', 'kind': 'a'})
                elif name in ('anchor', 'do'):
                    go = next((c for c in e.iter() if localname(c.tag) == 'go' and c.get('href')), None)
                    if go is not None:
                        label = ' '.join(' '.join(e.itertext()).split())[:160]
                        method = go.get('method', 'get').lower()
                        card_links.append({'href': go.get('href'), 'label': label or e.get('label') or e.get('type') or 'Go',
                                           'method': method, 'kind': name,
                                           'requires_inputs': bool(list(go)) or method != 'get'})
            card_data = {'id': card.get('id'), 'title': card.get('title'),
                         'text': ' '.join(' '.join(card.itertext()).split())[:500],
                         'links': card_links[:MAX_LINKS], 'inputs': inputs}
            result['cards'].append(card_data)
            result['links'].extend(card_links)
        if not result['cards']:
            result['notes'].append('WML root found but no cards')
    elif root is not None and localname(root.tag) == 'html' and (mime in XHTML_MP_MIME or re.search(r'WAPFORUM[^>]*XHTML\s+Mobile', text[:2000], re.I)):
        result['format'] = 'xhtml_mp'
    elif re.search(r'<\s*html\b', text, re.I):
        result['format'] = 'html'
        if 'application/xhtml+xml' == mime and root is not None:
            result['format'] = 'xhtml_generic'
    elif mime in WML_MIME:
        result['notes'].append('WML MIME declared, but WML document not validated')
    if result['format'] in ('xhtml_mp', 'html', 'xhtml_generic'):
        p = LinkExtractor()
        p.feed(text)
        result['links'] = p.links
        result['script_count'] = p.script_count
        result['forms_count'] = p.forms_count
    result['links'] = result['links'][:MAX_LINKS]
    return result


def grade(result: dict) -> tuple[str, str]:
    status = result.get('status')
    if status in (404, 410):
        return 'D-path-gone', 'This requested path returns HTTP 404/410; not proof that the entire site is gone.'
    if status in (401, 403, 429, 503) or result.get('error'):
        return 'U-inconclusive', 'Blocked, rate-limited or transport failure; compatibility not determined.'
    if status is None or not 200 <= status < 300:
        return 'U-inconclusive', 'Non-success response; requires review.'
    p = result['analysis']
    if p['format'] == 'wmlc' and p['valid_xml'] is True and p['cards']:
        if p['mime'] in WMLC_MIME:
            return 'A-wmlc-verified', 'Registered WML WBXML document decoded, with appropriate binary WAP MIME. Handset not tested.'
        return 'U-wmlc-wrong-mime', 'Valid compiled WML, but HTTP MIME does not declare WMLC/WBXML.'
    if p['format'] == 'wml' and p['valid_xml'] is True and p['cards']:
        if p['mime'] in WML_MIME:
            return 'A-wml-verified', 'Parseable WML deck and matching WAP MIME. DTD validity and physical-phone compatibility not tested.'
        return 'U-wml-wrong-mime', 'WML XML found, but MIME may prevent a legacy phone from displaying it.'
    if p['format'] == 'xhtml_mp' and p['valid_xml'] is True:
        return 'B-xhtml-mp-candidate', 'XHTML-MP identified; actual S60 browser compatibility still requires real-device testing.'
    if p['format'] == 'wbxml_candidate':
        return 'U-wbxml-unparsed', 'WBXML cannot be safely decoded; not counted as verified.'
    if result.get('redirects') and p['format'] in ('html','xhtml_generic'):
        return 'D-modern-redirect-candidate', 'Old-style request redirected to generic modern HTML. Path-specific, not site-wide.'
    if p['format'] in ('html', 'xhtml_generic'):
        return 'C-html-only', 'HTML returned; traditional WAP/S60 compatibility is not established.'
    return 'U-inconclusive', 'Response did not match a verified WAP format.'


def limited_read(fp, max_bytes: int) -> tuple[bytes, bool]:
    blob = fp.read(max_bytes + 1)
    return blob[:max_bytes], len(blob) > max_bytes


def probe(url: str, profile: str, timeout: float, max_bytes: int, allowed_origin: str | None = None, *, allow_tun_fake_ip: bool = False) -> tuple[dict, bytes]:
    record = {'url': url, 'profile': profile, 'request_headers': PROFILES[profile],
              'checked_at': now(), 'status': None, 'final_url': None,
              'content_type': None, 'content_encoding': None, 'redirects': [],
              'bytes_saved': 0, 'truncated': False, 'sha256': None, 'error': None}
    body = b''
    try:
        public_url(url, allow_tun_fake_ip=allow_tun_fake_ip)
        req = urllib.request.Request(url, headers={**PROFILES[profile], 'Accept-Encoding': 'gzip'}, method='GET')
        opener = urllib.request.build_opener(SafeRedirect(record['redirects'], allowed_origin, allow_tun_fake_ip=allow_tun_fake_ip), urllib.request.HTTPHandler(), urllib.request.HTTPSHandler())
        try:
            fp = opener.open(req, timeout=timeout)
        except urllib.error.HTTPError as err:
            fp = err
        with fp:
            record['status'] = fp.status
            record['final_url'] = fp.url
            record['content_type'] = fp.headers.get('Content-Type', '')
            record['content_encoding'] = fp.headers.get('Content-Encoding', '')
            body, record['truncated'] = limited_read(fp, max_bytes)
        if record['content_encoding'].lower() == 'gzip':
            # Separate input cap from decompression cap to avoid zip bombs.
            with gzip.GzipFile(fileobj=__import__('io').BytesIO(body)) as gz:
                body = gz.read(max_bytes + 1)
            if len(body) > max_bytes:
                body = body[:max_bytes]
                record['truncated'] = True
        record['bytes_saved'] = len(body)
        record['sha256'] = hashlib.sha256(body).hexdigest()
        record['analysis'] = inspect_markup(body, record['content_type'])
        if record['truncated']:
            record['analysis']['notes'].append('Response truncated; markup validity may be inconclusive')
    except Exception as exc:
        record['error'] = type(exc).__name__ + ': ' + str(exc)[:260]
        record['analysis'] = {'format':'unavailable','mime':None, 'links':[], 'cards':[], 'notes':[]}
    record['grade'], record['grade_reason'] = grade(record)
    if record['truncated'] and record['grade'].startswith(('A-', 'B-')):
        record['grade'] = 'U-truncated'
        record['grade_reason'] = 'Markup would qualify, but body was truncated; verification withheld.'
    return record, body


def offline_fixture(path: Path, content_type: str, profile: str = 'fixture') -> dict:
    body = path.read_bytes()
    r = {'url': path.as_uri(), 'profile': profile, 'checked_at': now(), 'status': 200,
         'final_url': path.as_uri(), 'redirects': [], 'content_type': content_type,
         'bytes_saved': len(body), 'sha256': hashlib.sha256(body).hexdigest(),
         'fixture': True, 'analysis': inspect_markup(body, content_type)}
    r['grade'], r['grade_reason'] = grade(r)
    return r


def reports_md(records: list[dict]) -> str:
    lines = [f'# WAP Probe v{VERSION} — Report', '', f'Generated UTC: {now()}', '',
             '> Caution: HTTP evidence only, not actual Nokia browser confirmation. Offline fixtures are synthetic.', '',
             '| URL | Profile | HTTP | Format | Grade |', '|---|---|---:|---|---|']
    for r in records:
        name = r['url'].replace('|','%7C')
        lines.append(f"| `{name}` | {r['profile']} | {r.get('status') or '—'} | {r['analysis']['format']} | {r['grade']} |")
    lines += ['', '## Detailed findings', '']
    for r in records:
        lines += [f"### {r['url']} ({r['profile']})", '',
                  f"- Result: **{r['grade']}** — {r['grade_reason']}",
                  f"- HTTP: {r.get('status')}, final URL: `{r.get('final_url')}`",
                  f"- Content-Type: `{r.get('content_type')}`; byte size: {r.get('bytes_saved', 0)}; SHA256: `{r.get('sha256')}`",
                  f"- Redirects: {len(r.get('redirects', []))}; links found: {len(r['analysis'].get('links', []))}; WML cards: {len(r['analysis'].get('cards', []))}"]
        if r.get('error'):
            lines.append('- Error: `' + r['error'] + '`')
        lines += ['']
    return '\n'.join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(description='Read-only traditional WAP protocol compatibility probe')
    p.add_argument('--url', action='append', default=[], help='Public HTTP(S) target; repeat for multiple URLs')
    p.add_argument('--url-file', type=Path, help='One public URL per line (lines beginning with # ignored)')
    p.add_argument('--profile', choices=['wap1', 's60', 'both'], default='both')
    p.add_argument('--out', type=Path, default=Path('wap-probe-results'))
    p.add_argument('--timeout', type=float, default=10.0)
    p.add_argument('--max-bytes', type=int, default=262144)
    p.add_argument('--delay', type=float, default=1.0, help='Delay between requests, minimum 1.0s')
    p.add_argument('--demo', action='store_true', help='Use bundled synthetic fixtures; never request network')
    p.add_argument('--allow-clash-fake-ip', action='store_true',
                   help='Opt in to Clash/Mihomo TUN DNS 198.18/15 for HOSTNAMES only; literal IPs remain blocked')
    p.add_argument('--inspect-file', type=Path, help='Analyze a previously captured local response body (offline)')
    p.add_argument('--content-type', default='application/octet-stream', help='Original Content-Type for --inspect-file')
    args = p.parse_args(argv)
    args.out.mkdir(parents=True, exist_ok=True)
    records = []
    if args.inspect_file:
        if not args.inspect_file.is_file():
            p.error('--inspect-file must be a readable file')
        records.append(offline_fixture(args.inspect_file.resolve(), args.content_type))
    elif args.demo:
        folder = Path(__file__).resolve().parent / 'fixtures'
        for filename, content_type in [
            ('sample_wml.wml', 'text/vnd.wap.wml; charset=utf-8'),
            ('sample_xhtml_mp.xhtml', 'application/vnd.wap.xhtml+xml; charset=utf-8'),
            ('sample_html.html', 'text/html; charset=utf-8'),
            ('sample_wml_wrong_mime.wml', 'text/html; charset=utf-8')]:
            records.append(offline_fixture(folder / filename, content_type))
    else:
        urls = list(args.url)
        if args.url_file:
            urls.extend(s.strip() for s in args.url_file.read_text(encoding='utf-8').splitlines()
                        if s.strip() and not s.strip().startswith('#'))
        urls = list(dict.fromkeys(urls))
        if not urls:
            p.error('Pass --url, --url-file or --demo')
        if not 0 < args.max_bytes <= 1024*1024:
            p.error('--max-bytes must be between 1 and 1048576')
        profiles = list(PROFILES) if args.profile == 'both' else [args.profile]
        for i, (url, profile) in enumerate((u, mode) for u in urls for mode in profiles):
            if i:
                time.sleep(max(1.0, args.delay))
            print(f'Checking {profile}: {url}', file=sys.stderr)
            r, body = probe(url, profile, args.timeout, args.max_bytes, allow_tun_fake_ip=args.allow_clash_fake_ip)
            r['allow_clash_fake_ip'] = args.allow_clash_fake_ip
            records.append(r)
            if body:
                suffix = hashlib.sha256((url + profile).encode()).hexdigest()[:12]
                evidence = f'{suffix}_{profile}.bin'
                (args.out / evidence).write_bytes(body)
                r['body_file'] = evidence
    (args.out / 'report.json').write_text(json.dumps({'version':VERSION, 'records': records}, ensure_ascii=False, indent=2), encoding='utf-8')
    (args.out / 'report.md').write_text(reports_md(records), encoding='utf-8')
    for r in records:
        print(f"{r['profile']:4s} {r['grade']:27s} {r['url']}")
    print('Saved:', (args.out / 'report.json').resolve())
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
