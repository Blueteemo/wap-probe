"""WBXML wire-format tests with independently hand-coded WML 1.3 tokens."""
from pathlib import Path
import unittest
import wap_probe as p
from wap_wbxml import decode_wmlc, WBXMLDecodeError

F = Path(__file__).resolve().parent / 'fixtures'
DATA = (F / 'binary_portal.wmlc').read_bytes()

class WBXMLTests(unittest.TestCase):
    def test_wmlc_binary_fixture(self):
        xml, header = decode_wmlc(DATA)
        self.assertEqual(header['public_id'], 10)
        self.assertEqual(header['charset_mib'], 106)
        self.assertEqual(header['wml_version'], '1.3')
        self.assertIn('这里是二进制 WAP 页面'.encode('utf-8'), xml)
        a = p.inspect_markup(DATA, 'application/vnd.wap.wmlc')
        self.assertEqual(a['format'], 'wmlc')
        self.assertEqual(a['cards'][0]['links'][0]['href'], '#next')
        self.assertEqual(p.grade({'status':200,'analysis':a})[0], 'A-wmlc-verified')

    def test_binary_wrong_mime_cannot_pass(self):
        a = p.inspect_markup(DATA, 'application/octet-stream')
        self.assertEqual(a['format'], 'wmlc')
        self.assertEqual(p.grade({'status':200,'analysis':a})[0], 'U-wmlc-wrong-mime')

    def test_misleading_mime_does_not_pass(self):
        a = p.inspect_markup(b'not actually WBXML', 'application/vnd.wap.wmlc')
        self.assertEqual(p.grade({'status':200,'analysis':a})[0], 'U-wbxml-unparsed')

    def test_non_wml_document_does_not_pass(self):
        invalid = bytes([0x03,0x05,0x6a,0x00,0x7f,0x01])  # SI 1.0, not WML
        a = p.inspect_markup(invalid,'application/vnd.wap.wmlc')
        self.assertEqual(p.grade({'status':200,'analysis':a})[0], 'U-wbxml-unparsed')

    def test_no_partial_wbxml_acceptance(self):
        for bad in (DATA[:-1], DATA + b'junk', DATA[:4], b'\x03\x0a\x6a\x81\x80\x80'):
            with self.subTest(bad=bad[:8]):
                with self.assertRaises(WBXMLDecodeError):
                    decode_wmlc(bad)

    def test_invalid_token_fails_closed(self):
        # Replace <a> with unknown WML code page 0 tag 0x0d.
        changed = DATA.replace(bytes([0xDC, 0x4A]), bytes([0xCD, 0x4A]))
        self.assertNotEqual(changed, DATA)
        with self.assertRaises(WBXMLDecodeError):
            decode_wmlc(changed)

    def test_reserved_extension_fails_closed(self):
        # EXT_0 is reserved, unlike WML variable reference tokens.
        changed = bytes([3,10,106,0,0x7f,0xC0,0x01])
        with self.assertRaisesRegex(WBXMLDecodeError,'reserved'):
            decode_wmlc(changed)

    def test_string_table_and_href_http_prefix(self):
        # String table 'abc\x00', id=STR_T(0), href=http:// + STR_I(host)
        data = bytes([3,10,106,4])+b'abc\x00'+bytes([0x7f,0xe7,0x55,0x83,0,1,0x60,0xdc,0x4b,3])+b'wap.example\x00'+bytes([1,3])+b'x\x00'+bytes([1,1,1,1])
        xml, _ = decode_wmlc(data)
        self.assertIn(b'id="abc"',xml)
        self.assertIn(b'href="http://wap.example"',xml)

    def test_official_wml_12_normative_binary_example(self):
        # WAP Forum WML 1.3 spec §14.4 (pp. 81-82): token stream,
        # with the historical 0x08 PUBLIC-ID corrected to 0x09 according to
        # the current OMA public-ID registry (0x08=CHANNEL, 0x09=WML 1.2).
        # of its published example, including EXT_T_2 reference to string table.
        # Source: https://www.openmobilealliance.org/tech/affiliates/wap/wap-191_104-wml-20010718-a.pdf
        data = (bytes([0x02,0x09,0x6a,0x04]) + b'X\x00Y\x00' +
                bytes([0x7f,0xe7,0x55,0x03]) + b'abc\x00' +
                bytes([0x33,0x01,0x60,0xe8,0x38,0x01,0xab,0x4b,0x03]) +
                b'xyz\x00' + bytes([0x88,0x03]) + b's\x00' +
                bytes([0x01,0x01,0x03]) + b'X: \x00' +
                bytes([0x82,0x00,0x26,0x03]) + b'Y: \x00' +
                bytes([0x82,0x02,0x26,0x03]) + b'Enter name: \x00' +
                bytes([0xaf,0x48,0x21,0x03]) + b'N\x00' +
                bytes([0x01,0x01,0x01,0x01]))
        xml, info = decode_wmlc(data)
        self.assertEqual(info['wml_version'], '1.2')
        self.assertEqual(info['variable_refs'], 2)
        self.assertIn(b'$(X:noesc)', xml)
        self.assertIn(b'$(Y:noesc)', xml)
        self.assertIn(b'http://xyz.org/s', xml)
        self.assertEqual(p.inspect_markup(data,'application/vnd.wap.wmlc')['format'],'wmlc')
        self.assertEqual((F / 'official_wml12_spec_example.wmlc').read_bytes(), data)

    def test_spec_example_unmodified_public_id_remains_rejected(self):
        # Erroneous public id printed by spec example would identify CHANNEL.
        raw = bytearray((F / 'official_wml12_spec_example.wmlc').read_bytes())
        raw[1] = 0x08
        with self.assertRaisesRegex(WBXMLDecodeError,'Not a registered WML'):
            decode_wmlc(bytes(raw))

    def test_inline_variables_in_href_remain_unexecuted(self):
        # Inline escaped variable appears after the href start token; it is
        # reconstructed literally rather than expanded or executed.
        data = (bytes([3,10,106,0,0x7f,0xe7,0x55,3]) +
                b'c\x00' + bytes([1,0x60,0xdc,0x4a,3]) +
                b'/user/\x00' + bytes([0x40]) + b'uid\x00' +
                bytes([1,3]) + b'Profile\x00' + bytes([1,1,1,1]))
        xml, info = decode_wmlc(data)
        self.assertIn(b'/user/$(uid:escape)', xml)
        self.assertEqual(info['variable_refs'], 1)
        a = p.inspect_markup(data,'application/vnd.wap.wmlc')
        self.assertEqual(a['links'][0]['href'], '/user/$(uid:escape)')
        self.assertEqual(p.grade({'status':200,'analysis':a})[0], 'A-wmlc-verified')
        self.assertTrue(any('NOT resolved' in n for n in a['notes']))
        self.assertEqual((F / 'variable_link.wmlc').read_bytes(), data)

    def test_new_wml_13_attribute_tokens(self):
        # Optional (0x28) and accesskey (0x5e) are present in the normative
        # WML 1.3 table; original v0.3 incorrectly decoded 'optional'.
        data = (bytes([3,10,106,0,0x7f,0xe7,0x55,3]) +
                b'c\x00' + bytes([1,0x60,0xaf,0x28,0x5e,3]) +
                b'1\x00' + bytes([1,1,1,1]))
        xml, _ = decode_wmlc(data)
        self.assertIn(b'optional="false"', xml)
        self.assertIn(b'accesskey="1"', xml)

    def test_invalid_variable_name_and_reserved_extension_rejected(self):
        base = bytes([3,10,106,0,0x7f,0x40])
        for suffix in (b'x)y\x00\x01',b'\x00\x01'):
            with self.subTest(suffix=suffix):
                with self.assertRaisesRegex(WBXMLDecodeError,'variable name'):
                    decode_wmlc(base+suffix)

if __name__ == '__main__': unittest.main()
