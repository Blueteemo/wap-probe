"""Imported raw HTTP evidence tests: no external network or DNS necessary."""
import gzip
import hashlib
from pathlib import Path
import tempfile
import unittest

import wap_capture as c

F = Path(__file__).resolve().parent / 'fixtures'
WML = (F/'portal.wml').read_bytes()
WMLC = (F/'binary_portal.wmlc').read_bytes()

class CaptureTests(unittest.TestCase):
    def test_import_wml_response_without_network(self):
        headers = b'HTTP/1.1 200 OK\r\nContent-Type: text/vnd.wap.wml; charset=utf-8\r\nContent-Length: 489\r\n\r\n'
        result, decoded = c.evaluate_capture(url='http://example.net/wap/',profile='wap1',headers=headers,body=WML)
        self.assertEqual(result['grade'],'A-wml-verified')
        self.assertEqual(result['evidence_origin'],'user_supplied_http_capture')
        self.assertFalse(result['live_verified'])
        self.assertEqual(result['http_capture_authenticity'],'not_independently_verified')
        self.assertEqual(decoded,WML)

    def test_compiled_wml_capture(self):
        headers = b'HTTP/1.1 200 OK\nContent-Type: application/vnd.wap.wmlc\n\n'
        result,_ = c.evaluate_capture(url='https://example.org/a.wmlc',profile='wap1',headers=headers,body=WMLC)
        self.assertEqual(result['grade'],'A-wmlc-verified')
        self.assertEqual(result['analysis']['cards'][1]['id'],'next')

    def test_gzip_wire_body_is_decompressed_bounded(self):
        binary = gzip.compress(WML)
        headers = b'HTTP/1.1 200 OK\r\nContent-Type: text/vnd.wap.wml\r\nContent-Encoding: gzip\r\n\r\n'
        r,plain = c.evaluate_capture(url='http://example.com/x',profile='wap1',headers=headers,body=binary)
        self.assertEqual(plain,WML)
        self.assertEqual(r['wire_sha256'],hashlib.sha256(binary).hexdigest())
        self.assertEqual(r['sha256'],hashlib.sha256(WML).hexdigest())
        self.assertEqual(r['grade'],'A-wml-verified')

    def test_known_decoded_body_must_not_be_decompressed_again(self):
        headers = b'HTTP/1.1 200 OK\nContent-Type: text/vnd.wap.wml\nContent-Encoding: gzip\n\n'
        r,data = c.evaluate_capture(url='http://example.com/x',profile='wap1',headers=headers,body=WML,body_kind='decoded')
        self.assertEqual(data,WML)
        self.assertEqual(r['body_kind'],'decoded')

    def test_redirect_and_interim_blocks_are_not_confused(self):
        headers = (b'HTTP/1.1 100 Continue\r\n\r\n'
                   b'HTTP/1.1 301 Moved\r\nLocation: /legacy\r\n\r\n'
                   b'HTTP/2 200 OK\r\nContent-Type: text/vnd.wap.wml\r\n\r\n')
        r,_ = c.evaluate_capture(url='https://example.com/',profile='wap1',headers=headers,body=WML,
                                  final_url='https://example.com/legacy')
        self.assertEqual(r['grade'],'A-wml-verified')
        self.assertEqual(len(r['redirects']),1)
        self.assertFalse(r['redirect_chain_mismatch'])
        self.assertEqual(r['final_url_inferred'],'https://example.com/legacy')

    def test_html_redirect_is_d_not_a(self):
        headers = (b'HTTP/1.1 302 Found\r\nLocation: /new\r\n\r\n'
                   b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n')
        r,_ = c.evaluate_capture(url='http://example.com/wap',profile='wap1',headers=headers,
                                 body=b'<html><body>modern</body></html>')
        self.assertEqual(r['grade'],'D-modern-redirect-candidate')

    def test_body_without_matching_mime_is_not_a(self):
        headers = b'HTTP/1.1 200 OK\nContent-Type: text/html\n\n'
        r,_ = c.evaluate_capture(url='http://example.com/',profile='wap1',headers=headers,body=WML)
        self.assertEqual(r['grade'],'U-wml-wrong-mime')

    def test_oversized_gzip_is_rejected(self):
        large = b'X'*(c.MAX_BODY_BYTES+10)
        headers = b'HTTP/1.1 200 OK\nContent-Encoding: gzip\nContent-Type: text/vnd.wap.wml\n\n'
        with self.assertRaisesRegex(c.CaptureError,'Decoded gzip body exceeds'):
            c.evaluate_capture(url='http://example.com/',profile='wap1',headers=headers,body=gzip.compress(large))

    def test_invalid_duplicate_or_missing_headers_rejected(self):
        for headers in [b'garbage\n\n',
                        b'HTTP/1.1 200 OK\nContent-Type: text/html\nContent-Type: text/vnd.wap.wml\n\n',
                        b'HTTP/1.1 301 Moved\n\nHTTP/1.1 200 OK\n\n']:
            with self.subTest(headers=headers):
                with self.assertRaises(c.CaptureError):
                    c.header_blocks(headers)

    def test_import_cli_retains_evidence(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root/'headers.txt').write_bytes(b'HTTP/1.1 200 OK\r\nContent-Type: text/vnd.wap.wml\r\n\r\n')
            (root/'body.bin').write_bytes(WML)
            rc = c.main(['--url','http://example.com/wap','--profile','wap1',
                         '--headers',str(root/'headers.txt'),'--body',str(root/'body.bin'),
                         '--out',str(root/'report')])
            self.assertEqual(rc,0)
            self.assertEqual((root/'report'/'response_body_wire.bin').read_bytes(),WML)
            import json
            record=json.loads((root/'report'/'report.json').read_text())['record']
            self.assertEqual(record['grade'],'A-wml-verified')
            self.assertFalse(record['live_verified'])

if __name__ == '__main__':
    unittest.main()
