#!/usr/bin/env python3
"""Conservative WML 1.0-1.3 WBXML decoder (code page 0).

Reads only a bounded, already-fetched byte string. Unsupported content fails
closed rather than guessing. This is NOT a general-purpose WBXML decoder.
Token tables from WML specification / Android kXML Wml.java.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET

WML_PUBLIC_IDS = {0x02: '1.0', 0x04: '1.1', 0x09: '1.2', 0x0A: '1.3'}
CHARSETS = {3: 'ascii', 4: 'latin-1', 106: 'utf-8', 2025: 'gb2312',
            113: 'gbk', 114: 'gb18030', 2026: 'big5', 1015: 'utf-16'}
TAG_NAMES = {
    0x1B: 'pre', 0x1C: 'a', 0x1D: 'td', 0x1E: 'tr', 0x1F: 'table',
    0x20: 'p', 0x21: 'postfield', 0x22: 'anchor', 0x23: 'access',
    0x24: 'b', 0x25: 'big', 0x26: 'br', 0x27: 'card', 0x28: 'do',
    0x29: 'em', 0x2A: 'fieldset', 0x2B: 'go', 0x2C: 'head',
    0x2D: 'i', 0x2E: 'img', 0x2F: 'input', 0x30: 'meta',
    0x31: 'noop', 0x32: 'prev', 0x33: 'onevent', 0x34: 'optgroup',
    0x35: 'option', 0x36: 'refresh', 0x37: 'select', 0x38: 'small',
    0x39: 'strong', 0x3B: 'template', 0x3C: 'timer', 0x3D: 'u',
    0x3E: 'setvar', 0x3F: 'wml',
}

# Token maps are normative WML code page 0, encoded here as name[, prefix].
ATTR_START = {
    0x05:'accept-charset',0x06:'align=bottom',0x07:'align=center',
    0x08:'align=left',0x09:'align=middle',0x0A:'align=right',
    0x0B:'align=top',0x0C:'alt',0x0D:'content',0x0F:'domain',
    0x10:'emptyok=false',0x11:'emptyok=true',0x12:'format',
    0x13:'height',0x14:'hspace',0x15:'ivalue',0x16:'iname',
    0x18:'label',0x19:'localsrc',0x1A:'maxlength',
    0x1B:'method=get',0x1C:'method=post',0x1D:'mode=nowrap',
    0x1E:'mode=wrap',0x1F:'multiple=false',0x20:'multiple=true',
    0x21:'name',0x22:'newcontext=false',0x23:'newcontext=true',
    0x24:'onpick',0x25:'onenterbackward',0x26:'onenterforward',
    0x27:'ontimer',0x28:'optional=false',0x29:'optional=true',
    0x2A:'path',0x2E:'scheme',0x2F:'sendreferer=false',
    0x30:'sendreferer=true',0x31:'size',0x32:'src',
    0x33:'ordered=true',0x34:'ordered=false',0x35:'tabindex',
    0x36:'title',0x37:'type',0x38:'type=accept',
    0x39:'type=delete',0x3A:'type=help',0x3B:'type=password',
    0x3C:'type=onpick',0x3D:'type=onenterbackward',
    0x3E:'type=onenterforward',0x3F:'type=ontimer',
    0x45:'type=options',0x46:'type=prev',0x47:'type=reset',
    0x48:'type=text',0x49:'type=vnd.',0x4A:'href',
    0x4B:'href=http://',0x4C:'href=https://',0x4D:'value',
    0x4E:'vspace',0x4F:'width',0x50:'xml:lang',0x52:'align',
    0x53:'columns',0x54:'class',0x55:'id',
    0x56:'forua=false',0x57:'forua=true',0x58:'src=http://',
    0x59:'src=https://',0x5A:'http-equiv',
    0x5B:'http-equiv=Content-Type',
    0x5C:'content=application/vnd.wap.wmlc;charset=',
    0x5D:'http-equiv=Expires',0x5E:'accesskey',
    0x5F:'enctype',0x60:'enctype=application/x-www-form-urlencoded',
    0x61:'enctype=multipart/form-data',0x62:'xml:space=preserve',
    0x63:'xml:space=default',0x64:'cache-control=no-cache',
}
ATTR_VALUE = {
    0x85:'.com/',0x86:'.edu/',0x87:'.net/',0x88:'.org/',
    0x89:'accept',0x8A:'bottom',0x8B:'clear',0x8C:'delete',
    0x8D:'help',0x8E:'http://',0x8F:'http://www.',
    0x90:'https://',0x91:'https://www.',0x93:'middle',
    0x94:'nowrap',0x95:'onpick',0x96:'onenterbackward',
    0x97:'onenterforward',0x98:'ontimer',0x99:'options',
    0x9A:'password',0x9B:'reset',0x9D:'text',0x9E:'top',
    0x9F:'unknown',0xA0:'wrap',0xA1:'www.',
}

class WBXMLDecodeError(ValueError):
    pass


class _Reader:
    def __init__(self, data: bytes):
        if not data or len(data) > 1_048_576:
            raise WBXMLDecodeError('WBXML input empty or too large')
        self.data = data
        self.pos = 0
        self.encoding = 'utf-8'
        self.strtab = b''
        self.tag_page = 0
        self.attr_page = 0
        self.steps = 0
        self.variable_refs = 0

    def byte(self) -> int:
        if self.pos >= len(self.data):
            raise WBXMLDecodeError('Truncated WBXML input')
        val = self.data[self.pos]
        self.pos += 1
        return val

    def mbuint(self) -> int:
        value = 0
        for _ in range(5):
            token = self.byte()
            if value > 0x1FFFFFF:
                raise WBXMLDecodeError('WBXML integer too large')
            value = (value << 7) | (token & 0x7F)
            if not token & 0x80:
                return value
        raise WBXMLDecodeError('Invalid WBXML multibyte integer')

    def read_cstring(self, buf: bytes | None = None, start: int | None = None) -> str:
        if buf is None:
            buf, start = self.data, self.pos
        assert start is not None
        if start < 0 or start >= len(buf):
            raise WBXMLDecodeError('String-table offset out of bounds')
        end = buf.find(b'\x00', start)
        if end < 0:
            raise WBXMLDecodeError('Unterminated WBXML string')
        if buf is self.data:
            self.pos = end + 1
        try:
            return buf[start:end].decode(self.encoding, 'strict')
        except UnicodeError as e:
            raise WBXMLDecodeError('Invalid encoded text in WBXML') from e

    def add_text(self, el: ET.Element, s: str):
        if len(el):
            last = el[-1]
            last.tail = (last.tail or '') + s
        else:
            el.text = (el.text or '') + s

    def strref(self) -> str:
        return self.read_cstring(self.strtab, self.mbuint())

    def atom(self, token: int) -> str:
        if token == 0x03:
            return self.read_cstring()
        if token == 0x83:
            return self.strref()
        if token == 0x02:
            codepoint = self.mbuint()
            if codepoint > 0x10FFFF or 0xD800 <= codepoint <= 0xDFFF:
                raise WBXMLDecodeError('Invalid Unicode entity')
            return chr(codepoint)
        if token in (0x40, 0x41, 0x42, 0x80, 0x81, 0x82):
            # WML-specific WBXML extensions represent VARIABLE REFERENCES, not
            # executable expressions. Preserve them, but NEVER substitute values.
            # The browser refuses to navigate links containing a dollar sign.
            name = self.read_cstring() if token < 0x80 else self.strref()
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,79}', name):
                raise WBXMLDecodeError('Unsafe or invalid WML variable name')
            self.variable_refs += 1
            suffix = {0: 'escape', 1: 'unesc', 2: 'noesc'}[token & 0x03]
            return f'$({name}:{suffix})'
        if token in (0xC0, 0xC1, 0xC2, 0xC3):
            raise WBXMLDecodeError('Reserved WML extension or opaque token unsupported')
        raise WBXMLDecodeError(f'Unsupported WBXML global token 0x{token:02x}')

    def attributes(self) -> dict[str, str]:
        out: dict[str, str] = {}
        key: str | None = None
        value = ''
        while True:
            self.steps += 1
            if self.steps > 50000:
                raise WBXMLDecodeError('Too many WBXML tokens')
            tok = self.byte()
            if tok == 0x01:
                if key is not None:
                    out[key] = value
                return out
            if tok == 0x00:
                self.attr_page = self.byte()
                if self.attr_page != 0:
                    raise WBXMLDecodeError('Unsupported WBXML attribute code page')
                continue
            # Variable tokens are attribute VALUE extensions, not starts.
            if tok in (0x40, 0x41, 0x42, 0x80, 0x81, 0x82):
                if key is None:
                    raise WBXMLDecodeError('Variable reference before attribute name')
                value += self.atom(tok)
                continue
            if tok == 0x04 or (0x05 <= tok <= 0x7F and tok not in (0x43,)):
                if key is not None:
                    out[key] = value
                raw = self.strref() if tok == 0x04 else ATTR_START.get(tok)
                if not raw:
                    raise WBXMLDecodeError(f'Unknown WML attribute token 0x{tok:02x}')
                key, sep, value = raw.partition('=')
                continue
            if key is None:
                raise WBXMLDecodeError('Attribute value before name')
            if tok in (0x02, 0x03, 0x83):
                value += self.atom(tok)
            elif tok in ATTR_VALUE:
                value += ATTR_VALUE[tok]
            else:
                raise WBXMLDecodeError(f'Unsupported WBXML attribute value 0x{tok:02x}')

    def element(self, first: int, depth: int = 0) -> ET.Element:
        if depth > 64:
            raise WBXMLDecodeError('WBXML nesting depth exceeded')
        if first in (0x04, 0x44, 0x84, 0xC4):
            tag = self.strref()
        else:
            tag = TAG_NAMES.get(first & 0x3F)
        if not tag or not tag.replace('-', '').replace('_','').isalnum():
            raise WBXMLDecodeError(f'Unknown WBXML WML tag 0x{first:02x}')
        has_attr = bool(first & 0x80)
        has_body = bool(first & 0x40)
        attrs = self.attributes() if has_attr else {}
        el = ET.Element(tag, attrs)
        if not has_body:
            return el
        while True:
            self.steps += 1
            if self.steps > 50000:
                raise WBXMLDecodeError('Too many WBXML tokens')
            tok = self.byte()
            if tok == 0x01:
                return el
            if tok == 0x00:
                self.tag_page = self.byte()
                if self.tag_page != 0:
                    raise WBXMLDecodeError('Unsupported WBXML tag code page')
            elif tok in (0x02, 0x03, 0x83, 0x40, 0x41, 0x42, 0x80, 0x81, 0x82):
                self.add_text(el, self.atom(tok))
            elif tok in (0x43, 0xC0, 0xC1, 0xC2, 0xC3):
                raise WBXMLDecodeError('WBXML PI/reserved extension/opaque not supported')
            else:
                el.append(self.element(tok, depth+1))


def decode_wmlc(data: bytes) -> tuple[bytes, dict]:
    """Return XML bytes and evidence metadata, or raise on unsupported WBXML."""
    r = _Reader(data)
    version = r.byte()
    if version > 3:
        raise WBXMLDecodeError('Unsupported WBXML version')
    public_id = r.mbuint()
    if public_id == 0:
        raise WBXMLDecodeError('Literal WBXML public identifier not supported')
    if public_id not in WML_PUBLIC_IDS:
        raise WBXMLDecodeError(f'Not a registered WML document: public_id={public_id}')
    mib = r.mbuint()
    if mib not in CHARSETS:
        raise WBXMLDecodeError(f'Unsupported WBXML charset MIBEnum={mib}')
    r.encoding = CHARSETS[mib]
    size = r.mbuint()
    if size > 65536 or size > len(data) - r.pos:
        raise WBXMLDecodeError('Invalid/oversized WBXML string table')
    r.strtab = r.data[r.pos:r.pos+size]
    r.pos += size
    first = r.byte()
    root = r.element(first)
    if root.tag != 'wml':
        raise WBXMLDecodeError('WBXML root is not wml')
    if r.pos != len(data):
        raise WBXMLDecodeError('Trailing WBXML bytes')
    xml_body = ET.tostring(root, encoding='utf-8', xml_declaration=True)
    return xml_body, {'wbxml_version': f'{(version >> 4) + 1}.{version & 0x0F}',
                      'wml_version': WML_PUBLIC_IDS[public_id],
                      'public_id': public_id, 'charset_mib': mib,
                      'decoded_xml_bytes': len(xml_body),
                      'variable_refs': r.variable_refs,
                      'variables_resolved': False,
                      'coverage': 'WML code page 0, no execution; WML variables preserved as placeholders'}
