"""Deterministic offline tests; never touches the network."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import wap_probe as w

F = Path(__file__).parent / 'fixtures'

class ProbeTests(unittest.TestCase):
    def test_wml(self):
        r = w.offline_fixture(F/'sample_wml.wml','text/vnd.wap.wml; charset=UTF-8')
        self.assertEqual(r['grade'],'A-wml-verified')
        self.assertEqual(len(r['analysis']['cards']),2)
        self.assertTrue(any(a['href']=='#forum' for a in r['analysis']['links']))

    def test_xhtml_mp(self):
        r = w.offline_fixture(F/'sample_xhtml_mp.xhtml','application/vnd.wap.xhtml+xml')
        self.assertEqual(r['grade'],'B-xhtml-mp-candidate')
        self.assertEqual(r['analysis']['links'][0]['href'],'forum.xhtml')

    def test_modern_html_not_accepted(self):
        r = w.offline_fixture(F/'sample_html.html','text/html')
        self.assertEqual(r['grade'],'C-html-only')
        self.assertEqual(r['analysis']['script_count'],1)

    def test_wml_mime_mismatch(self):
        r = w.offline_fixture(F/'sample_wml_wrong_mime.wml','text/html')
        self.assertEqual(r['grade'],'U-wml-wrong-mime')

    def test_wml_mime_on_html_not_accepted(self):
        a = w.inspect_markup(b'<html><body>not WML</body></html>', 'text/vnd.wap.wml')
        self.assertEqual(a['format'],'html')
        self.assertEqual(w.grade({'status':200,'analysis':a, 'redirects': []})[0], 'C-html-only')

    def test_404_is_path_only(self):
        r = {'status':404,'analysis':{'format':'unknown'},'redirects':[]}
        self.assertEqual(w.grade(r)[0], 'D-path-gone')

    def test_blocked_is_unknown(self):
        self.assertEqual(w.grade({'status':403,'analysis':{'format':'html'}})[0], 'U-inconclusive')

    def test_redirect_to_modern_page(self):
        a = w.inspect_markup(b'<html><body>new</body></html>','text/html')
        r = {'status':200, 'analysis':a, 'redirects':[{'status':302}]}
        self.assertEqual(w.grade(r)[0], 'D-modern-redirect-candidate')

    def test_wbxml_mime_stays_unverified(self):
        a = w.inspect_markup(b'\x03\x01\x6a\x00\x45', 'application/vnd.wap.wmlc')
        self.assertEqual(a['format'],'wbxml_candidate')
        self.assertEqual(w.grade({'status':200,'analysis':a})[0],'U-wbxml-unparsed')

    def test_gb18030(self):
        b = '<?xml version="1.0" encoding="gb2312"?><wml><card id="c"><p>中文测试</p></card></wml>'.encode('gb18030')
        a = w.inspect_markup(b, 'text/vnd.wap.wml')
        self.assertEqual(a['format'],'wml')
        self.assertIn('中文测试',a['cards'][0]['text'])

    def test_private_hosts_blocked_without_dns(self):
        for target in ('file:///etc/passwd', 'http://127.0.0.1/', 'http://localhost/', 'http://192.168.1.2/', 'http://10.0.0.2/'):
            with self.subTest(target=target):
                with self.assertRaises(ValueError):
                    w.public_url(target, check_dns=False)

    def test_legacy_dtd_not_fetched(self):
        # XML parses with an external DTD declaration; it isn't downloaded.
        a = w.inspect_markup((F/'sample_wml.wml').read_bytes(), 'text/vnd.wap.wml')
        self.assertTrue(a['valid_xml'])

if __name__ == '__main__':
    unittest.main(verbosity=2)
