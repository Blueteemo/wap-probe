#!/usr/bin/env python3
"""Independently reclassify local third-party HTTP evidence. No network requests.

Metadata (including MIME, URL and timestamp) is a claim by the collector; hashes
verify integrity relative to its manifest, not authenticity of the web origin.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

import wap_probe as p

MAX_FILE_BYTES = 2 * 1024 * 1024
BASE = 'deepseek_review/'
REPORTS = (
    'evidence/online_candidates/report.json',
    'evidence/online_international/report.json',
    'evidence/wmlc_guesses/report.json',
    'evidence/wmlc_guesses2/report.json',
    'evidence/wapit/report.json',
)
WALKS = (
    'evidence/live_walk_bs0dd/walk.json',
    'evidence/live_walk_kannel/walk.json',
)


def bounded_read(archive: ZipFile, path: str) -> bytes:
    if '..' in Path(path).parts or not path.startswith(BASE):
        raise ValueError('Unsafe archive path')
    info = archive.getinfo(path)
    if info.file_size > MAX_FILE_BYTES:
        raise ValueError('Archive member exceeds replay size limit: ' + path)
    return archive.read(info)


def analyze_archive(source: Path) -> dict:
    summary = {'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
               'source': source.name, 'collector': 'local DeepSeek, externally supplied',
               'authenticated_live_fetch': False,
               'integrity': {'checked': 0, 'failures': []},
               'replayed': [], 'walks': [], 'errors': []}
    with ZipFile(source) as z:
        manifest = bounded_read(z, BASE+'evidence/MANIFEST.sha256').decode('utf-8')
        for entry in manifest.splitlines():
            fields = entry.split(maxsplit=2)
            if len(fields) != 3:
                summary['integrity']['failures'].append('bad manifest entry')
                continue
            expected, timestamp, rel = fields
            name = BASE+'evidence/'+rel.removeprefix('./')
            try:
                observed = hashlib.sha256(bounded_read(z, name)).hexdigest()
                summary['integrity']['checked'] += 1
                if observed != expected:
                    summary['integrity']['failures'].append(name)
            except (KeyError, ValueError) as e:
                summary['integrity']['failures'].append(name+': '+str(e))
        for report in REPORTS:
            try:
                data = json.loads(bounded_read(z, BASE+report))
            except KeyError:
                continue
            for record in data.get('records', []):
                filename = record.get('body_file')
                if not filename:
                    summary['replayed'].append({'report': report, 'url': record['url'],
                                                 'profile':record['profile'], 'result':'no_body',
                                                 'collector_grade':record['grade']})
                    continue
                fullpath = BASE+report.rsplit('/',1)[0]+'/'+filename
                try:
                    body = bounded_read(z, fullpath)
                    digest = hashlib.sha256(body).hexdigest()
                    match_hash = digest == record.get('sha256')
                    analysis = p.inspect_markup(body,record.get('content_type') or '')
                    candidate = {**record, 'analysis': analysis}
                    regraded = p.grade(candidate)[0]
                    if record.get('truncated') and regraded.startswith(('A-', 'B-')):
                        regraded='U-truncated'
                    matched = match_hash and regraded == record['grade']
                    summary['replayed'].append({'report': report, 'url':record['url'],
                        'profile':record['profile'], 'collector_grade':record['grade'],
                        'replayed_grade':regraded, 'format':analysis['format'],
                        'sha256_match':match_hash, 'match':matched})
                except (KeyError, ValueError, TypeError) as e:
                    summary['errors'].append(fullpath+': '+str(e))
        for report in WALKS:
            try:
                j=json.loads(bounded_read(z,BASE+report))
            except KeyError:
                continue
            origin=BASE+report.rsplit('/',1)[0]+'/evidence/'
            checks=[]
            for fetch in j.get('fetches',[]):
                try:
                    body=bounded_read(z,origin+fetch['sha256']+'.bin')
                    digest_match=hashlib.sha256(body).hexdigest()==fetch['sha256']
                    analysis=p.inspect_markup(body,fetch['content_type'])
                    grade=p.grade({'status':fetch['http_status'],'analysis':analysis,'redirects':[]})[0]
                    checks.append({'url':fetch['url'],'sha256_match':digest_match,
                                   'grade':grade,'matches_collector':grade==fetch['grade']})
                except (KeyError, ValueError) as e:
                    summary['errors'].append(origin+': '+str(e))
            summary['walks'].append({'report':report,'fetches':checks,
                                     'events_reported':len(j.get('events',[]))})
    return summary


def main():
    a=argparse.ArgumentParser(description='Read-only replay of original DeepSeek HTTP evidence')
    a.add_argument('--review-zip',type=Path,required=True)
    a.add_argument('--out',type=Path,default=Path('reports/replay'))
    args=a.parse_args()
    result=analyze_archive(args.review_zip)
    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/'replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    total=sum(1 for r in result['replayed'] if 'match' in r)
    mismatched=[r for r in result['replayed'] if r.get('match') is False]
    fails=result['integrity']['failures']
    lines=['# Offline evidence replay', '', 'This replays collector-provided captures; **not** an independent online check.',
        '',f"- Manifest files verified: {result['integrity']['checked']}; failures: {len(fails)}",
        f'- Classified HTTP responses: {total}; discrepancies: {len(mismatched)}',
        f"- Navigation traces: {len(result['walks'])}",f"- Replay errors: {len(result['errors'])}",
        '', '## Replayed responses', '', '| URL | Profile | Collector | Replayed | Match |', '|---|---|---|---|---|']
    for r in result['replayed']:
        if 'match' in r:
            lines.append(f"| {r['url']} | {r['profile']} | {r['collector_grade']} | {r['replayed_grade']} | {'yes' if r['match'] else 'NO'} |")
    lines += ['', '## Caveat', '', 'Response MIME, dates and origin URLs are reported by the collector; a file hash cannot prove a response came from its stated server. Physical handset tests are not included.']
    (args.out/'replay.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f'Replayed {total} HTTP responses, {len(mismatched)} discrepancies; '
          f"integrity {result['integrity']['checked']} files, {len(fails)} failures")
    return 1 if fails or mismatched or result['errors'] else 0


if __name__=='__main__':
    raise SystemExit(main())
