#!/usr/bin/env python3
"""Small read-only WML deck navigator for research. No JavaScript, POST, or auth.

A recorded walk with explicit link selections is NOT autonomous crawling.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import posixpath
import time
from pathlib import Path
from urllib.parse import urljoin, urlsplit, urldefrag, unquote

import wap_probe as p

MAX_STEPS = 12


def same_origin(a: str, b: str) -> bool:
    x, y = urlsplit(a), urlsplit(b)
    def identity(z):
        return (z.scheme.lower(), (z.hostname or '').lower(), z.port or (443 if z.scheme == 'https' else 80))
    return identity(x) == identity(y)


class WAPNavigator:
    def __init__(self, start: str, *, profile='wap1', offline=False, timeout=10.0,
                 max_bytes=262144, delay=1.0, allow_tun_fake_ip=False):
        self.start = start
        self.profile = profile
        self.offline = offline
        self.timeout = timeout
        self.max_bytes = max_bytes
        self.delay = delay
        self.allow_tun_fake_ip = allow_tun_fake_ip
        self.events: list[dict] = []
        self.fetches: list[dict] = []
        self.captures: dict[str, bytes] = {}
        self.body = b''
        self.page = {}
        self.current_url = ''
        self.origin = ''
        self.card_index = 0
        self.file_root: Path | None = None
        if offline:
            start_path = Path(start).expanduser().resolve(strict=True)
            if not start_path.is_file():
                raise ValueError('Offline entry must be a file')
            self.file_root = start_path.parent
            self.origin = start_path.as_uri()
            self._open(start_path.as_uri())
        else:
            p.public_url(start, allow_tun_fake_ip=self.allow_tun_fake_ip)
            self.origin = start
            self._open(start)

    def _open(self, url: str):
        fragment = urlsplit(url).fragment
        base, _ = urldefrag(url)
        if self.offline:
            split = urlsplit(base)
            if split.scheme != 'file' or split.netloc not in ('', 'localhost'):
                raise ValueError('Offline navigation cannot use network URLs')
            path = Path(unquote(split.path)).resolve(strict=True)
            if not path.is_relative_to(self.file_root) or not path.is_file():
                raise ValueError('Offline navigation restricted to fixture directory')
            if path.stat().st_size > self.max_bytes:
                raise ValueError('Fixture exceeds byte limit')
            body = path.read_bytes()
            mime = {'.wml': 'text/vnd.wap.wml', '.xhtml': 'application/vnd.wap.xhtml+xml',
                    '.html':'text/html', '.htm': 'text/html', '.wmlc':'application/vnd.wap.wmlc'}.get(path.suffix.lower(), 'application/octet-stream')
            rec = p.offline_fixture(path, mime, self.profile)
            rec['offline_mime_inferred_from_extension'] = True
        else:
            if not same_origin(self.origin, base):
                raise ValueError('External origin blocked for navigation; provide it as a new start URL')
            p.public_url(base, allow_tun_fake_ip=self.allow_tun_fake_ip)
            if self.fetches:
                time.sleep(max(1.0, self.delay))
            kw = {'allowed_origin': self.origin}
            if self.allow_tun_fake_ip:
                kw['allow_tun_fake_ip'] = True
            rec, body = p.probe(base, self.profile, self.timeout, self.max_bytes, **kw)
            final_url = rec.get('final_url') or base
            if not same_origin(self.origin, final_url):
                raise ValueError('Cross-origin redirect occurred; content withheld')
            if rec.get('error') or rec.get('status') != 200:
                raise ValueError(f"Cannot open HTTP page: {rec.get('status')} {rec.get('error')}")
            approved = ('A-wml-verified', 'A-wmlc-verified') if self.profile == 'wap1' else ('A-wml-verified', 'A-wmlc-verified', 'B-xhtml-mp-candidate')
            if rec.get('grade') not in approved:
                raise ValueError('Response not verified for selected profile: '+str(rec.get('grade')))
        # Validate destination fragment before replacing the current page.
        # A failed link must not leave a partially navigated browser state.
        if fragment and rec['analysis'].get('cards') and not any(
                card.get('id') == fragment for card in rec['analysis']['cards']):
            raise ValueError('WML card not found: ' + fragment)
        self.page = rec['analysis']
        self.body = body
        self.current_url = (rec.get('final_url') or base)
        self.card_index = 0
        digest = hashlib.sha256(body).hexdigest()
        self.captures[digest] = body
        self.fetches.append({'url':base, 'sha256':digest,
                             'bytes':len(body), 'grade':rec['grade'], 'http_status':rec['status'],
                             'content_type':rec.get('content_type'), 'fixture':self.offline})
        if fragment:
            self._select_card(fragment)
        self.events.append(self.snapshot(event='open'))

    def _select_card(self, card_id: str):
        cards = self.page.get('cards', [])
        for idx, card in enumerate(cards):
            if card.get('id') == card_id:
                self.card_index = idx
                return
        raise ValueError('WML card not found: '+card_id)

    def options(self):
        cards = self.page.get('cards', [])
        if cards:
            return cards[self.card_index].get('links', [])
        return [{'href':x['href'], 'label':x['label'], 'method':'get', 'kind':'a'} for x in self.page.get('links', [])]

    def snapshot(self, event='view'):
        cards = self.page.get('cards', [])
        if cards:
            card = cards[self.card_index]
            title, content = card.get('title') or card.get('id') or '(untitled)', card.get('text', '')
            card_id = card.get('id')
        else:
            title, content, card_id = self.page.get('format','unknown'), self.page.get('preview', ''), None
        return {'event':event, 'url':self.current_url, 'format':self.page.get('format'),
                'card_id':card_id, 'title':title, 'text':content,
                'choices':[{**link, 'number':i+1} for i,link in enumerate(self.options())]}

    def choose(self, choice: int):
        links = self.options()
        if choice < 1 or choice > len(links):
            raise ValueError(f'Choice {choice} out of range (1..{len(links)})')
        link = links[choice - 1]
        if link.get('method','get').lower() != 'get' or link.get('requires_inputs'):
            raise ValueError('Submitting forms is intentionally unsupported')
        href = link.get('href') or ''
        if '$' in href:
            raise ValueError('WML variables not supported; refusing dynamic URL')
        target = urljoin(self.current_url, href)
        previous, frag = urldefrag(self.current_url)
        next_base, next_frag = urldefrag(target)
        if next_base == previous and next_frag:
            self._select_card(next_frag)
            self.events.append(self.snapshot(event='card'))
        else:
            self._open(target)


def printable(snap: dict) -> str:
    lines = [f"[{snap['event']}] {snap['title']} [{snap['format']}]", f"URL: {snap['url']}"]
    if snap.get('card_id'):
        lines.append('Card: '+snap['card_id'])
    if snap.get('text'):
        lines.append('Text: '+snap['text'])
    for link in snap['choices']:
        label = link['label'] or '(unlabelled)'
        # Typical WML labels already include an in-page numeral; avoid doubling it.
        import re
        label = re.sub(r'^\[\d+\]\s*', '', label)
        extra = ' (FORM BLOCKED)' if link.get('requires_inputs') or link.get('method') != 'get' else ''
        lines.append(f"  [{link['number']}] {label} -> {link['href']}{extra}")
    if not snap['choices']:
        lines.append('  (no selectable links)')
    return '\n'.join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description='Research-grade read-only WML card navigator')
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument('--file', type=Path, help='Offline WML/XHTML fixture (MIME inferred; no network)')
    src.add_argument('--url', help='Public WAP URL, verified WML or XHTML-MP only')
    ap.add_argument('--profile', choices=p.PROFILES, default='wap1')
    ap.add_argument('--steps', default='', help='Comma-separated, explicit one-based link selections (max 12)')
    ap.add_argument('--out', type=Path, default=Path('reports/walk'))
    ap.add_argument('--timeout', type=float, default=10.0)
    ap.add_argument('--delay', type=float, default=1.0)
    ap.add_argument('--allow-clash-fake-ip', action='store_true',
                    help='Opt in to Clash/Mihomo TUN DNS 198.18/15 for hostnames only')
    args = ap.parse_args(argv)
    try:
        steps = [int(x.strip()) for x in args.steps.split(',') if x.strip()]
    except ValueError:
        ap.error('--steps must be comma-separated link numbers')
    if len(steps) > MAX_STEPS:
        ap.error(f'At most {MAX_STEPS} manually selected steps')
    navigator = WAPNavigator(str(args.file if args.file else args.url), offline=args.file is not None,
                             profile=args.profile, timeout=args.timeout, delay=args.delay,
                             allow_tun_fake_ip=args.allow_clash_fake_ip)
    print(printable(navigator.events[-1]))
    for step in steps:
        print('\n--- select', step, '---')
        try:
            navigator.choose(step)
        except (ValueError, OSError) as e:
            print('Stopped:',e)
            break
        print(printable(navigator.events[-1]))
    args.out.mkdir(parents=True, exist_ok=True)
    evidence_dir = args.out / 'evidence'
    evidence_dir.mkdir(exist_ok=True)
    for digest, body in navigator.captures.items():
        (evidence_dir / (digest + '.bin')).write_bytes(body)
    doc = {'version':'0.3.3', 'offline':navigator.offline, 'allow_clash_fake_ip':args.allow_clash_fake_ip,
           'warning':'Offline inferred MIME is not an HTTP response. Online results are not proof of handset usability.',
           'fetches':navigator.fetches, 'events':navigator.events}
    (args.out/'walk.json').write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding='utf-8')
    (args.out/'walk.txt').write_text('\n\n'.join(printable(s) for s in navigator.events)+'\n', encoding='utf-8')
    print('\nSaved:', (args.out/'walk.json').resolve())
    print('Evidence:', evidence_dir.resolve())
    return 0


if __name__=='__main__':
    raise SystemExit(main())
