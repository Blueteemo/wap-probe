#!/usr/bin/env python3
"""Safely analyze externally collected HTTP response evidence.

This DOES NOT make HTTP requests. It is for captures collected independently
(e.g. by a local researcher whose machine has working DNS). Transport metadata
is **asserted by the submitter**, not cryptographically authenticated.

Usage: curl -sS -L -D headers.txt -o body.bin -H 'Accept: text/vnd.wap.wml' ...
Then: python3 wap_capture.py --url ... --profile wap1 --headers headers.txt \
        --body body.bin --out reports/imported
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import re
from pathlib import Path
from urllib.parse import urljoin

import wap_probe as p

MAX_HEADER_BYTES = 262144
MAX_BODY_BYTES = 1048576


class CaptureError(ValueError):
    pass


def header_blocks(raw: bytes) -> list[dict]:
    """Parse curl -D output including interim HTTP responses and redirects."""
    if not raw or len(raw) > MAX_HEADER_BYTES:
        raise CaptureError('Empty/oversized response headers')
    text = raw.decode('iso-8859-1')
    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    blocks: list[dict] = []
    current: dict | None = None
    for line in lines:
        if re.match(r'^HTTP/\d(?:\.\d)?\s+\d{3}(?:\s|$)', line, re.I):
            match = re.match(r'^HTTP/\d(?:\.\d)?\s+(\d{3})', line, re.I)
            assert match
            current = {'status': int(match.group(1)), 'headers': {}}
            blocks.append(current)
        elif line == '':
            current = None
        elif current is not None:
            if line[0] in ' \t':
                raise CaptureError('Folded headers are unsupported')
            if ':' not in line:
                raise CaptureError('Malformed HTTP response header')
            k, v = line.split(':', 1)
            if not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", k):
                raise CaptureError('Invalid HTTP header name')
            key = k.lower()
            if key in current['headers'] and key in ('content-type','content-encoding','location'):
                raise CaptureError('Ambiguous duplicate critical header: ' + k)
            current['headers'][key] = v.strip()
    # Ignore 100 Continue; retain actual redirect chain and final response.
    blocks = [b for b in blocks if b['status'] >= 200]
    if not blocks:
        raise CaptureError('No final HTTP status line found')
    if any(300 <= b['status'] < 400 and not b['headers'].get('location') for b in blocks[:-1]):
        raise CaptureError('Redirect chain is missing Location header')
    if any(b['status'] >= 400 for b in blocks[:-1]):
        raise CaptureError('Unexpected HTTP error before final response')
    return blocks


def bounded_decode(data: bytes, content_encoding: str, *, body_kind: str) -> bytes:
    if len(data) > MAX_BODY_BYTES:
        raise CaptureError('Captured body exceeds 1 MiB')
    if body_kind == 'decoded':
        return data
    encoding = content_encoding.strip().lower()
    if encoding in ('', 'identity'):
        return data
    if encoding == 'gzip':
        try:
            with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
                out = stream.read(MAX_BODY_BYTES + 1)
        except (OSError, EOFError, ValueError) as exc:
            raise CaptureError('Invalid gzip response body') from exc
        if len(out) > MAX_BODY_BYTES:
            raise CaptureError('Decoded gzip body exceeds 1 MiB')
        return out
    raise CaptureError('Unsupported Content-Encoding: ' + encoding)


def evaluate_capture(*, url: str, profile: str, headers: bytes, body: bytes,
                     body_kind: str = 'wire', final_url: str | None = None) -> tuple[dict, bytes]:
    if profile not in p.PROFILES:
        raise CaptureError('Unknown legacy client profile')
    # This is NOT a request; validate only URL syntax, not current DNS.
    from urllib.parse import urlsplit
    parsed = urlsplit(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
        raise CaptureError('Capture URL must be HTTP(S) without credentials')
    blocks = header_blocks(headers)
    last = blocks[-1]
    if final_url is not None:
        outurl = urlsplit(final_url)
        if outurl.scheme not in ('http','https') or not outurl.hostname or outurl.username or outurl.password:
            raise CaptureError('Invalid final URL')
    else:
        outurl = None
    redirects = []
    current = url
    for b in blocks[:-1]:
        if 300 <= b['status'] < 400:
            destination = urljoin(current, b['headers']['location'])
            redirects.append({'status':b['status'], 'from':current, 'to':destination})
            current = destination
    if outurl is not None and redirects and current != final_url:
        # Capturing tools can normalize encoded paths and fragments. Record the
        # discrepancy rather than inventing a fully verified URL chain.
        mismatch = True
    else:
        mismatch = False
    decoded = bounded_decode(body, last['headers'].get('content-encoding',''), body_kind=body_kind)
    mime = last['headers'].get('content-type','')
    record = {
        'url':url, 'profile':profile, 'checked_at':None, 'status':last['status'],
        'final_url':final_url, 'final_url_inferred':current if redirects else url,
        'content_type':mime, 'content_encoding':last['headers'].get('content-encoding',''),
        'redirects':redirects, 'redirect_chain_mismatch':mismatch,
        'bytes_saved':len(decoded), 'sha256':hashlib.sha256(decoded).hexdigest(),
        'wire_sha256':hashlib.sha256(body).hexdigest(), 'wire_bytes':len(body),
        'truncated':False, 'error':None,
        'analysis':p.inspect_markup(decoded,mime),
        'evidence_origin':'user_supplied_http_capture',
        'http_capture_authenticity':'not_independently_verified',
        'live_verified':False, 'body_kind':body_kind,
        'request_headers':'not independently observed; profile label supplied by researcher',
    }
    record['grade'], record['grade_reason'] = p.grade(record)
    record['analysis']['notes'].append(
        'This is imported HTTP evidence: format was validated, but collection time, source and header authenticity were NOT independently verified.')
    if mismatch:
        record['analysis']['notes'].append('Provided final URL differs from reconstructed Location chain')
    return record, decoded


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='Analyze independently captured WAP response (no networking)')
    parser.add_argument('--url',required=True)
    parser.add_argument('--profile',choices=list(p.PROFILES),required=True)
    parser.add_argument('--headers',type=Path,required=True,help='Raw response header blocks, e.g. curl -D headers.txt')
    parser.add_argument('--body',type=Path,required=True,help='Raw downloaded body bytes, e.g. curl -o body.bin')
    parser.add_argument('--body-kind',choices=['wire','decoded'],default='wire',
                        help='wire: Content-Encoding still applied (default); decoded: already decompressed')
    parser.add_argument('--final-url',help='Final URL output by curl -w %%{url_effective}')
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args(argv)
    try:
        if args.headers.stat().st_size > MAX_HEADER_BYTES or args.body.stat().st_size > MAX_BODY_BYTES:
            raise CaptureError('Input capture file exceeds safety limit')
        raw_headers, raw_body = args.headers.read_bytes(), args.body.read_bytes()
        record, decoded = evaluate_capture(
            url=args.url,profile=args.profile,headers=raw_headers,body=raw_body,
            body_kind=args.body_kind,final_url=args.final_url)
    except (CaptureError, OSError, ValueError) as exc:
        parser.error(str(exc))
    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/'response_headers.txt').write_bytes(raw_headers)
    (args.out/'response_body_wire.bin').write_bytes(raw_body)
    (args.out/'response_body_decoded.bin').write_bytes(decoded)
    report = {'version':'0.3.2','capture_provenance':'external_unverified',
              'record':record}
    (args.out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    md = p.reports_md([record]) + '\n\n**Evidence provenance:** imported, not independently authenticated or a verified live-site observation.\n'
    (args.out/'report.md').write_text(md,encoding='utf-8')
    print(f"{record['grade']}  {record['analysis']['format']}  {args.url}")
    print('Saved:',(args.out/'report.json').resolve())
    return 0

if __name__=='__main__':
    raise SystemExit(main())
